java-csveader
=============

DESCRIPTION
======

Class to convert CSV files to 2d arrays for use in Java programs.

USAGE
======
Running CSVReader as a Stand-alone will prompt the user for an input file and print out the CSV file after making it an array.
Calling the getter method contained within the class will return the array instead, for use in any other class. 

ADDITIONAL INFO
======
Also contains LineCounter.java which will run on its own if needed.
