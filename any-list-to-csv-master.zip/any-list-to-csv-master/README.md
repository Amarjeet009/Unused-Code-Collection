# any-list-to-csv
Simple Java project that contains a class that allows to transform any java.util.List to CSV format
