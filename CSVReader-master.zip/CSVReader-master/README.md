# CSVReader
# A Java util to read CSV files from HDFS 
# Support read by line
