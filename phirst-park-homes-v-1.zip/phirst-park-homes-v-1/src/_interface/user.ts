export interface IUser {
    status: boolean;
    msg: string;
    data: { };
}
