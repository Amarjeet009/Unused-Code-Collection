export interface IAuth {
    status: boolean;
    bearer: string;
    msg: string;
}
