export class PaymentModel {
    merchantId: string;
    amount: number;
    orderRef: string;
    currCode: number;
    mpsMode: string;
    payType: string;
    lang: string;
    payMethod: string;
    secureHash: string;
    successUrl: string;
    failUrl: string;
    cancelUrl: string;
}