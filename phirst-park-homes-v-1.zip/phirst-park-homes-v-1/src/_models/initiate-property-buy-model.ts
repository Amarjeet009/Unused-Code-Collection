export class InitiatePropertyBuyModel {
     email: string;
     mobile: string;
     firstName: string;
     middleName: string;
     lastName: string;
     phoneNo: string;
     propertyId: string;

}