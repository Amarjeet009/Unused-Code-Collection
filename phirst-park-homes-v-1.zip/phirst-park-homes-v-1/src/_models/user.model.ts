export class UserLogin {
    email: String;
    password: String;
}

export class ChangePasswordModel {
    userId: String;
    password: String;
    newPassword: String;
    confirmPassword: String;
}