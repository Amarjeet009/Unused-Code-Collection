export class ReservedSaleDocumentsUpload {
    reservedSaleDocuments: {
        conditionalPurchaseAgreement: any;
        buyerInformationSheet: any;
        computationSheet: any;
        houseSpecificationList: any;
        buyersGuide: any;
        _5ConvenientBuyerSteps: any;
        proofOfReservationFeePayment: any;
        _1stIdOfBuyer: any;
        dataPrivacyConsent: any;
        intentToPurchase: any;

    };
}