export class UpdateUserModel {
    buyerID: string;
    buyerType: string;
    isIndividualBuyer: boolean;
    buyerDocStatus: string;
    buyerPersonalInformation: {
        suffix: string;
        firstName: string;
        middleName: string;
        lastName: string;
        emailId: string;
        gender: string;
        civilStatus: string;
        DOB: string;
        birthplace: string;
        numberOfChildren: number;
        citizenship: string;
        taxIdentificationNumber: string;
        typeOfValidId: string;
        idNo: string
    };
    buyerContactInformation: {
        residentialAddress: string;
        residentailZip: string;
        otherAddress: string;
        otherZip: string;
        mobile: number;
        phone: number;
    };
    buyerEmploymentInformation: {
        employmentType: string;
        specificEmployement: string;
        employerOrBusinessName: string;
        employerOrBusinessAddress: string;
        employerPhone: string;
        employerMobile: string;
        employerEmailAddress: string;
        occupationTitle: string;
        occupationRank: string;
        yearsOfEmployment: number;
    };
    buyerAttornyInfo: {
        attorneyInFactFirstName: string;
        attorneyInFactLastName: string;
        attorneyInFactMiddleName: string;
        attorneyInFactSuffixName: string;
        attorneyInFactGender: string;
        attorneyInFactCivilStatus: string;
        attorneyInFactBirthdate: string;
        attorneyInFactCitizenship: string;
        attorneyInFactTypeOfValidId: string;
        attorneyInFactIdNo: string;
        attorneyInFactMobile: number;
        attorneyInFactPhone: number;
        attorneyInFactEmailAddress: string;
        attorneyInFactResidentialAddress: string;
        attorneyInFactZipCode: string;
        attorneyInFactEmployment: string;
        attorneyInFactRelationToBuyer: string;
    };
    spousePersonalInformation: {
        spouseFirstName: string;
        spouseMiddleName: string;
        spouseLastName: string;
        spouseSuffixName: string;
        spouseGender: string;
        spouseBirthDate: string;
        spouseBirthPlace: string;
        spouseCitizenship: string;
        spouseNoOfChildren: 0;
        spouseTaxIdentificationNo: string;
        spouseTypeOfValidId: string;
        spouseIdNo: string;
        spousePhone: number;
        spouseMobile: number;
        spouseEmailAddress: string;
    };
    spouseEmploymentInformation: {
        spouseEmploymentType: string;
        spouseSpecificEmployement: string;
        spouseEmployerOrBusinessName: string;
        spouseEmployerOrBusinessAddress: string;
        spouseEmployerPhone: string;
        spouseEmployerMobile: string;
        spouseEmployerEmailAddress: string;
        spouseOccupationTitle: string;
        spouseOccupationRank: string;
        spouseYearsOfEmployment: number;
    };
    spouseAttorneyInfactInformation: {
        spouseAttorneyInFactFirstName: string;
        spouseAttorneyInFactMiddleName: string;
        spouseAttorneyInFactLastName: string;
        spouseAttorneyInFactSuffixName: string;
        spouseAttorneyInFactGender: string;
        spouseAttorneyInFactCivilStatus: string;
        spouseAttorneyInFactBirthdate: string;
        spouseAttorneyInFactCitizenship: string;
        spouseAttorneyInFactTypeOfValidId: string;
        spouseAttorneyInFactIdNo: string;
        spouseAttorneyInFactMobile: string;
        spouseAttorneyInFactPhone: string;
        spouseAttorneyInFactEmailAddress: string;
        spouseAttorneyInFactResidentialAddress: string;
        spouseAttorneyInFactZipCode: string;
        spouseAttorneyInFactEmployment: string;
        spouseAttorneyInFactRelationToBuyer: string;
    };
    nIBuyerBusinessInformation: {
        nIBNameOfBusiness: string;
        nIBNatureOfBusiness: string;
        nIBYearsInOperation: string;
        nIBBusinessType: string;
        nIBContactNo: string;
        nIBEmailAddress: string;
        nIBTaxIdentificationNo: string;
        nIBSecRegistrationNo: string;
        nIBSssNo: string;
        nIBPrincipalOfficeAddress: string;
        nIBPrincipalOfficeAddressZipCode: string;
        nIBOtherAddress: string;
        nIBOtherAddressZipCode: string;
    };
    authorisedSignatoryInformation: {
        aSIFirstName: string;
        aSIMiddleName: string;
        aSILastName: string;
        aSISuffixName: string;
        aSIGender: string;
        aSICivilStatus: string;
        aSIBirthDate: string;
        aSICitizenship: string;
        aSIDesignation: string;
        aSItaxIdentificationNo: string;
        aSITypeOfValidId: string;
        aSIIdNo: string;
        aSIMobile: string;
        aSIOfficePhoneNo: string;
        aSIfaxNo: string;
        aSIEmailAddress: string;
        aSIAddress: string;
        aSIZipCode: string;
    };
    contactPersonInformation:
        {
            cPIFirstName: string;
            cPIMiddleName: string;
            cPILastName: string;
            cPISuffixName: string;
            cPIGender: string;
            cPICivilStatus: string;
            cPIBirthDate: string;
            cPICitizenship: string;
            cPIDesignation: string;
            cPItaxIdentificationNo: string;
            cPITypeOfValidId: string;
            cPIIdNo: string;
            cPIMobile: string;
            cPIOfficePhoneNo: string;
            cPIfaxNo: string;
            cPIEmailAddress: string;
            cPIAddress: string;
            cPIZipCode: string;
        };
    profileInformationForm: {
        knowAboutProject: string;
        ifKnowAboutProjectIsReferral: string;
        purposeOfBuying: string;
        ifPurposeOfBuyingIsInvestment: string;
        currentHomeOwnership: string;
        lengthOfStay: string;
        monthlyHouseholdIncomeBuyer: string;
        monthlyHouseholdIncomeSpouse: string;
        followupPreferredDays: string;
        followupPreferredTime: string;
        followupContactNo: string;
        followupContactNoType: string;
        preferredMailingAdddress: string;
        preferredMailingAdddressType: string;
    };
    accountInformation: {
        inTheNameOfKey: string;                                                                          // new update  // optional
        inTheNameOf: string;                                                                                   //optional
        inTheNameOfType: string;                                                                         //optional
        marriedTo: string;                                                                                          //optional
        spouses: string;                                                                                               //optional
        coOwners: string;
        others: string;                                                                                         //optional
    };
}
