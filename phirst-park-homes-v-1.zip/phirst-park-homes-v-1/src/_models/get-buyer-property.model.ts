export class GetBuyerPropertyModel {
    id: number;
    buyer_id: number;
    property_id: string;
    property_name: string;
    resv_fee: number;
    initiated_time: Date;
    status: string;
    payment_term: number;
    project_id: string;
    phase_id: string;
    batch_id: string;
    unit_id: string;
    unit_price: number;
    order_ref: string;
    resv_payment_status: string;
    payment_ref: string;
}