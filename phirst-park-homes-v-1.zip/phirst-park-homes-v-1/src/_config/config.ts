export class Config {
 public static api_url = 'http://172.16.11.127:3000';
 // public static api_url = 'http://3.17.77.247:3000'; //server url
  public static merchantId = '18157267';
  public static pesopay = {
    merchantId: '18157267',
    // successUrl: 'http://localhost:3000/success',
    // failUrl: 'http://localhost:3000/fail',
    // cancelUrl: 'http://localhost:3000/cancel'
    successUrl: 'http://3.17.77.247:80/success',
    failUrl: 'http://3.17.77.247:80/fail',
    cancelUrl: 'http://3.17.77.247:80/cancel'
  };
}