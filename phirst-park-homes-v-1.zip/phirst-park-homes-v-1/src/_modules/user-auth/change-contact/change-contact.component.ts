import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-contact',
  templateUrl: './change-contact.component.html',
  styleUrls: ['./change-contact.component.css']
})
export class ChangeContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scrollTo(500, 0);
  }

}
