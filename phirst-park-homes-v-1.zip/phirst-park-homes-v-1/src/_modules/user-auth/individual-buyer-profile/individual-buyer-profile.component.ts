import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../_services/user.service';

@Component({
  selector: 'app-individual-buyer-profile',
  templateUrl: './individual-buyer-profile.component.html',
  styleUrls: ['./individual-buyer-profile.component.css']
})
export class IndividualBuyerProfileComponent implements OnInit {
  detailsModel = {
    'userId': localStorage.getItem('emailId')
  };
  userDetailsList: any;
  firstName = '------';
  middleName = '------';
  lastName = '------';
  emailId = '-------';
  mobileNo: any;
  phoneNo: any;
  suffix = '-----';
  gender = '-----';
  DOB: any;
  birthplace = '-----';
  numberOfChildren = 0;
  citizenship = '------';
  civilStatus = '-------';
  taxIdentificationNumber = '-----';
  typeOfValidId = '------';
  idNo = '----';
  residentialAddress = '-------';
  residentailZip = '-------';
  otherAddress = '--------';
  otherZip = '--------';
  employmentType: any;
  specificEmployement = '-----';
  employerOrBusinessName = '------';
  employerOrBusinessAddress = '-----';
  employerPhone: any;
  employerMobile: any;
  employerEmailAddress = '-----';
  occupationTitle = '----';
  occupationRank = 0;
  yearsOfEmployment = 0;

  attorneyInFactFirstName = '----';
  attorneyInFactLastName = '----';
  attorneyInFactMiddleName = '----';
  attorneyInFactSuffixName = '----';
  attorneyInFactGender = '-----';
  attorneyInFactCivilStatus = '-----';
  attorneyInFactBirthdate: any;
  attorneyInFactCitizenship = '-----';
  attorneyInFactTypeOfValidId = '-----';
  attorneyInFactIdNo = '-----';
  attorneyInFactMobile = '-----';
  attorneyInFactPhone = '-----';
  attorneyInFactEmailAddress = '-----';
  attorneyInFactResidentialAddress = '-----';
  attorneyInFactZipCode = '-----';
  attorneyInFactEmployment = '-----';
  attorneyInFactRelationToBuyer = '-----';

  spouseFirstName = '-----';
  spouseMiddleName = '-----';
  spouseLastName = '-----';
  spouseSuffixName = '-----';
  spouseGender = '-----';
  spouseBirthDate: any;
  spouseBirthPlace = '-----';
  spouseCitizenship = '-----';
  spouseNoOfChildren = 0;
  spouseTaxIdentificationNo = '-----';
  spouseTypeOfValidId = '-----';
  spouseIdNo = '-----';
  spousePhone = '-----';
  spouseMobile = '-----';
  spouseEmailAddress = '-----';

  spouseEmploymentType = '-----';
  spouseSpecificEmployement = '-----';
  spouseEmployerOrBusinessName = '-----';
  spouseEmployerOrBusinessAddress = '-----';
  spouseEmployerPhone = '-----';
  spouseEmployerMobile = '-----';
  spouseEmployerEmailAddress = '-----';
  spouseOccupationTitle = '-----';
  spouseOccupationRank = '-----';
  spouseYearsOfEmployment = '-----';

  spouseAttorneyInFactFirstName = '-----';
  spouseAttorneyInFactMiddleName = '-----';
  spouseAttorneyInFactLastName = '-----';
  spouseAttorneyInFactSuffixName = '-----';
  spouseAttorneyInFactGender = '-----';
  spouseAttorneyInFactCivilStatus = '-----';
  spouseAttorneyInFactBirthdate: any;
  spouseAttorneyInFactCitizenship = '-----';
  spouseAttorneyInFactTypeOfValidId = '-----';
  spouseAttorneyInFactIdNo = '-----';
  spouseAttorneyInFactMobile = '-----';
  spouseAttorneyInFactPhone = '-----';
  spouseAttorneyInFactEmailAddress = '-----';
  spouseAttorneyInFactResidentialAddress = '-----';
  spouseAttorneyInFactZipCode = '-----';
  spouseAttorneyInFactEmployment = '-----';
  spouseAttorneyInFactRelationToBuyer = '-----';

  constructor(private userService: UserService) { }

  ngOnInit() {
    window.scrollTo(500, 0);
    this.userService.getBuyerDetails(this.detailsModel).subscribe(responseData => {
      this.userDetailsList = responseData;
      this.firstName = responseData.buyerPersonalInformation.firstName;
      this.middleName = responseData.buyerPersonalInformation.middleName;
      this.lastName = responseData.buyerPersonalInformation.lastName;
      this.emailId = responseData.buyerPersonalInformation.emailId;
      this.mobileNo = responseData.buyerContactInformation.mobile;
      this.phoneNo = responseData.buyerContactInformation.phone;
      this.suffix = responseData.buyerPersonalInformation.suffix;
      this.gender = responseData.buyerPersonalInformation.gender;
      if (responseData.buyerPersonalInformation.DOB ===  'N/A' || responseData.buyerPersonalInformation.DOB === 'NaN/NaN/NaN') {
        this.DOB = null;
      } else {
        this.DOB = responseData.buyerPersonalInformation.DOB;
      }
      this.birthplace = responseData.buyerPersonalInformation.birthplace;
      this.numberOfChildren = responseData.buyerPersonalInformation.numberOfChildren;
      this.citizenship = responseData.buyerPersonalInformation.citizenship;
      this.civilStatus = responseData.buyerPersonalInformation.civilStatus;
      this.taxIdentificationNumber = responseData.buyerPersonalInformation.taxIdentificationNumber;
      this.typeOfValidId = responseData.buyerPersonalInformation.typeOfValidId;
      this.idNo = responseData.buyerPersonalInformation.idNo;
      this.residentialAddress = responseData.buyerContactInformation.residentialAddress;
      this.residentailZip = responseData.buyerContactInformation.residentailZip;
      this.otherAddress = responseData.buyerContactInformation.otherAddress;
      this.otherZip = responseData.buyerContactInformation.otherZip;
      this.employmentType = responseData.buyerEmploymentInformation.employmentType;
      this.employerOrBusinessName = responseData.buyerEmploymentInformation.employerOrBusinessName;
      this.employerOrBusinessAddress = responseData.buyerEmploymentInformation.employerOrBusinessAddress;
      this.employerPhone = responseData.buyerEmploymentInformation.employerPhone;
      this.employerMobile = responseData.buyerEmploymentInformation.employerMobile;
      this.employerEmailAddress = responseData.buyerEmploymentInformation.employerEmailAddress;
      this.specificEmployement = responseData.buyerEmploymentInformation.specificEmployement;
      this.occupationTitle = responseData.buyerEmploymentInformation.occupationTitle;
      this.occupationRank = responseData.buyerEmploymentInformation.occupationRank;
      this.yearsOfEmployment = responseData.buyerEmploymentInformation.yearsOfEmployment;


      this.attorneyInFactFirstName = responseData.buyerAttornyInfo.attorneyInFactFirstName;
      this.attorneyInFactLastName = responseData.buyerAttornyInfo.attorneyInFactLastName;
      this.attorneyInFactMiddleName = responseData.buyerAttornyInfo.attorneyInFactMiddleName;
      this.attorneyInFactSuffixName = responseData.buyerAttornyInfo.attorneyInFactSuffixName;
      this.attorneyInFactGender = responseData.buyerAttornyInfo.attorneyInFactGender;
      this.attorneyInFactCivilStatus = responseData.buyerAttornyInfo.attorneyInFactCivilStatus;

      if (responseData.buyerAttornyInfo.attorneyInFactBirthdate === 'N/A' || responseData.buyerAttornyInfo.attorneyInFactBirthdate === 'NaN/NaN/NaN') {
        this.attorneyInFactBirthdate = null;
      } else {
        this.attorneyInFactBirthdate = responseData.buyerAttornyInfo.attorneyInFactBirthdate;
      }
      this.attorneyInFactCitizenship = responseData.buyerAttornyInfo.attorneyInFactCitizenship;
      this.attorneyInFactTypeOfValidId = responseData.buyerAttornyInfo.attorneyInFactFirstName;
      this.attorneyInFactIdNo = responseData.buyerAttornyInfo.attorneyInFactIdNo;
      this.attorneyInFactMobile = responseData.buyerAttornyInfo.attorneyInFactMobile;
      this.attorneyInFactPhone = responseData.buyerAttornyInfo.attorneyInFactPhone;
      this.attorneyInFactEmailAddress = responseData.buyerAttornyInfo.attorneyInFactEmailAddress;
      this.attorneyInFactResidentialAddress = responseData.buyerAttornyInfo.attorneyInFactResidentialAddress;
      this.attorneyInFactZipCode = responseData.buyerAttornyInfo.attorneyInFactZipCode;
      this.attorneyInFactEmployment = responseData.buyerAttornyInfo.attorneyInFactEmployment;
      this.attorneyInFactRelationToBuyer = responseData.buyerAttornyInfo.attorneyInFactRelationToBuyer;


      this.spouseFirstName = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseFirstName;
      this.spouseMiddleName = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseMiddleName;
      this.spouseLastName = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseLastNames;
      this.spouseSuffixName = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseSuffixName;
      this.spouseGender = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseGender;
      if(responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseBirthDate === 'N/A' || responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseBirthDate  === 'NaN/NaN/NaN') {
        this.spouseBirthDate = null;
      } else {
        this.spouseBirthDate = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseBirthDate;

      }
      this.spouseBirthPlace = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseBirthPlace;
      this.spouseCitizenship = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseCitizenship;
      this.spouseNoOfChildren = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseNoOfChildren;
      this.spouseTaxIdentificationNo = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseTaxIdentificationNo;
      this.spouseTypeOfValidId = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseTypeOfValidId;
      this.spouseIdNo = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseIdNo;
      this.spousePhone = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spousePhone;
      this.spouseMobile = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseMobile;
      this.spouseEmailAddress = responseData.individualBuyerSpouseInfo.spousePersonalInformation.spouseEmailAddress;

      this.spouseEmploymentType = responseData.individualBuyerSpouseInfo.spouseEmploymentInformation.spouseEmploymentType;
      this.spouseSpecificEmployement = responseData.individualBuyerSpouseInfo.spouseEmploymentInformation.spouseSpecificEmployement;
      this.spouseEmployerOrBusinessName = responseData.individualBuyerSpouseInfo.spouseEmploymentInformation.spouseEmployerOrBusinessName;
      this.spouseEmployerOrBusinessAddress = responseData.individualBuyerSpouseInfo.spouseEmploymentInformation.spouseEmployerOrBusinessAddress;
      this.spouseEmployerPhone = responseData.individualBuyerSpouseInfo.spouseEmploymentInformation.spouseEmployerPhone;
      this.spouseEmployerMobile = responseData.individualBuyerSpouseInfo.spouseEmploymentInformation.spouseEmployerMobile;
      this.spouseEmployerEmailAddress = responseData.individualBuyerSpouseInfo.spouseEmploymentInformation.spouseEmployerEmailAddress;
      this.spouseOccupationTitle = responseData.individualBuyerSpouseInfo.spouseEmploymentInformation.spouseOccupationTitle;
      this.spouseOccupationRank = responseData.individualBuyerSpouseInfo.spouseEmploymentInformation.spouseOccupationRank;
      this.spouseYearsOfEmployment = responseData.individualBuyerSpouseInfo.spouseEmploymentInformation.spouseYearsOfEmployment;


      this.spouseAttorneyInFactFirstName = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactFirstName;
      this.spouseAttorneyInFactMiddleName = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactMiddleName;
      this.spouseAttorneyInFactLastName = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactLastName;
      this.spouseAttorneyInFactSuffixName = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactSuffixName;
      this.spouseAttorneyInFactGender = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactGender;
      this.spouseAttorneyInFactCivilStatus = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactCivilStatus;
      if (responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactBirthdate === 'N/A' || responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactBirthdate  === 'NaN/NaN/NaN') {
        this.spouseAttorneyInFactBirthdate = null;
      } else {
        this.spouseAttorneyInFactBirthdate = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactBirthdate;
      }
      this.spouseAttorneyInFactCitizenship = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactCitizenship;
      this.spouseAttorneyInFactTypeOfValidId = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactTypeOfValidId;
      this.spouseAttorneyInFactIdNo = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactIdNo;
      this.spouseAttorneyInFactMobile = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactMobile;
      this.spouseAttorneyInFactPhone = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactPhone;
      this.spouseAttorneyInFactEmailAddress = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactEmailAddress;
      this.spouseAttorneyInFactResidentialAddress = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactResidentialAddress;
      this.spouseAttorneyInFactZipCode = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactZipCode;
      this.spouseAttorneyInFactEmployment = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactEmployment;
      this.spouseAttorneyInFactRelationToBuyer = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation.spouseAttorneyInFactRelationToBuyer;
    });
  }



}
