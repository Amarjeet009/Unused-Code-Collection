import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndividualBuyerProfileComponent } from './individual-buyer-profile.component';

describe('IndividualBuyerProfileComponent', () => {
  let component: IndividualBuyerProfileComponent;
  let fixture: ComponentFixture<IndividualBuyerProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndividualBuyerProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndividualBuyerProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
