import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transaction-view',
  templateUrl: './transaction-view.component.html',
  styleUrls: ['./transaction-view.component.css']
})
export class TransactionViewComponent implements OnInit {
  invoiceDownloadUrl = 'http://dr2myglbq65g4.cloudfront.net/BuyerDocuments/invoice.pdf';
  constructor() { }

  ngOnInit() {
    window.scrollTo(500, 0);
  }

}
