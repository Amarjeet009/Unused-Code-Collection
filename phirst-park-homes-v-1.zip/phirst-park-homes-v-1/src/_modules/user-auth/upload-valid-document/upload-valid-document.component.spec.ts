import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadValidDocumentComponent } from './upload-valid-document.component';

describe('UploadValidDocumentComponent', () => {
  let component: UploadValidDocumentComponent;
  let fixture: ComponentFixture<UploadValidDocumentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadValidDocumentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadValidDocumentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
