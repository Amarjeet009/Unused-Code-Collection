import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/_services/user.service';
import { NotificationsService } from 'angular2-notifications';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';

@Component({
    selector: 'app-upload-valid-document',
    templateUrl: './upload-valid-document.component.html',
    styleUrls: ['./upload-valid-document.component.css']
})
export class UploadValidDocumentComponent implements OnInit {

    reservedSaleDocuments = {
        _conditionalPurchaseAgreementFileName: '',
        _buyerInformationSheetFilname: '',
        _computationSheetFileName: '',
        _houseSpecificationListFileName: '',
        _buyersGuideFilename: '',
        _5ConvenientBuyerStepsFileName: '',
        _proofOfReservationFeePaymentFileName: '',
        _1stIdOfBuyerFileName: '',
        _dataPrivacyConsentFilename: '',
        _intentToPurchaseFilename: '',
        category: 'reserved_sale_documents',
        conditionalPurchaseAgreement: null,
        buyerInformationSheet: null,
        computationSheet: null,
        houseSpecificationList: null,
        buyersGuide: null,
        _5ConvenientBuyerSteps: null,
        proofOfReservationFeePayment: null,
        _1stIdOfBuyer: null,
        dataPrivacyConsent: null,
        intentToPurchase: null
    };

    contractedSaleDocumentsModel = {
        _proofOfIncomeFileName: '',
        _proofOfBillingFileName: '',
        _proofOfCivilStatusFileName: '',
        _proofOfDownpaymentFileName: '',
        _unifiedHomeLoanApplicationFileName: '',
        _deedOfAbsoluteSaleFileName: '',
        _tINOrbIR1904FileName: '',
        _requirementChecklistFileName: '',
        category: 'contracted_sale_documents',
        proofOfIncome: null,
        proofOfBilling: null,
        proofOfCivilStatus: null,
        proofOfDownpayment: null,
        unifiedHomeLoanApplication: null,
        deedOfAbsoluteSale: null,
        tINOrbIR1904: null,
        requirementChecklist: null
    };

    ifLocallyEmployedModel = {
        _certificateOfEmployentFileName: '',
        _latestITROfBIR1906FileName: '',
        _2ndIdOfBuyerFileName: '',
        _1stIdOfSpouseFileName: '',
        _2ndIdOfSpouseFileName: '',
        _1stIdOfCoborrowerFileName: '',
        _2ndIdOfCoborrowerFileName: '',
        category: 'if_locally_employed',
        certificateOfEmployent: null,
        latestITROfBIR1906: null,
        latest3MonthsPayslips: [],
        _2ndIdOfBuyer: null,
        _1stIdOfSpouse: null,
        _2ndIdOfSpouse: null,
        _1stIdOfCoborrower: null,
        _2ndIdOfCoborrower: null
    };

    ifEmployedAbroadModel = {
        _specialPowerOfAttorneyInfactFileName: '',
        _POEAContractAttorneyInfactFileName: '',
        _2ndIdOfBuyerAttorneyInfactFileName: '',
        _IdOfBuyerAttorneyInfactFileName: '',
        _idOfSpouseAttorneyInfactFileName: '',
        _1stIdOfSpouseAttorneyInfactFileName: '',
        _2ndIdOfSpouseAttorneyInfactFileName: '',
        _1stIdOfCoborrowerAttorneyInfactFileName: '',
        _2ndIdOfCoborrowerAttorneyInfactFileName: '',
        category: 'if_employed_abroad',
        specialPowerOfAttorneyInfact: null,
        _POEAContractAttorneyInfact: null,
        latest3MonthsPayslipsAttorneyInfact: [],
        latest3MonthsRemitanncesAttorneyInfact: [],
        _2ndIdOfBuyerAttorneyInfact: null,
        _IdOfBuyerAttorneyInfact: null,
        _IdOfSpouseAttorneyInfact: null,
        _1stIdOfSpouseAttorneyInfact: null,
        _2ndIdOfSpouseAttorneyInfact: null,
        _1stIdOfCoborrowerAttorneyInfact: null,
        _2ndIdOfCoborrowerAttorneyInfact: null
  
    };
  
    ifSelfEmployedModel = {
        _certificateOfBusinessRegistrationIfSelfEmployedFileName: '',
        _auditedFinancialStatementIfSelfEmployedFileName: '',
        _latest6MonthsBankStatementIfSelfEmployedFileName: '',
        _2ndIdOfBuyerIfSelfEmployedFileName: '',
        _1stIdOfSpouseIfSelfEmployedFileName: '',
        _2ndIdOfSpouseIfSelfEmployedFileName: '',
        _1stIdOfCoborrowerIfSelfEmployedFileName: '',
        _2ndIdOfCoborrowerIfSelfEmployedFileName: '',
        category: 'if_self_employed',
        certificateOfBusinessRegistrationIfSelfEmployed: null,
        auditedFinancialStatementIfSelfEmployed: null,
        _latest6MonthsBankStatementIfSelfEmployed: null,
        _2ndIdOfBuyerIfSelfEmployed: null,
        _1stIdOfSpouseIfSelfEmployed: null,
        _2ndIdOfSpouseIfSelfEmployed: null,
        _1stIdOfCoborrowerIfSelfEmployed: null,
        _2ndIdOfCoborrowerIfSelfEmployed: null
    };
    additionalRequirementsBanksModel = {
        _birthCertificateFileName: '',
        _affidavitOfCitizenshipFileName: '',
        _oathOfAllegianceFileName: '',
        _letterOfUndertakingFileName: '',
        category: 'additional_requirements_banks',
        birthCertificate: null,
        affidavitOfCitizenship: null,
        oathOfAllegiance: null,
        letterOfUndertaking: null
    };
  
    sourceOfIncomeFromRentalModel = {
        _leaseContractFileName: '',
        _photocopyOfTitleFileName: '',
        category: 'source_of_income_from_rental',
        leaseContract: null,
        photocopyOfTitle: null
    };
  
    busy1: Subscription;
    busy2: Subscription;
    busy3: Subscription;
    busy4: Subscription;
    busy5: Subscription;
    busy6: Subscription;
    busy7: Subscription;
  
    userModel = {
        'userId': localStorage.getItem('emailId')
      };
      public reserved_sale_documents: any = 0;
      public contracted_sale_documents: any = 0;
      public if_locally_employed: any = 0;
      public if_employed_abroad: any = 0;
      public if_self_employed: any = 0;
      public additional_requirements_banks: any = 0;
      public source_of_income_from_rental: any = 0;

    constructor(
        private userService: UserService, 
        private notiService: NotificationsService,
        private router: Router) {}
  
   ngOnInit() {
    window.scrollTo(500, 0);
    this.getBuyerBasicDetails();
  }

  getBuyerBasicDetails() {
    this.userService.getBuyerBasicDetails(this.userModel).subscribe(responseData => {
        if (responseData.status === true) {
          this.reserved_sale_documents = responseData.data.reserved_sale_documents;
          this.contracted_sale_documents = responseData.data.contracted_sale_documents;
          this.if_locally_employed = responseData.data.if_locally_employed;
          this.if_employed_abroad = responseData.data.if_employed_abroad;
          this.if_self_employed = responseData.data.if_self_employed;
          this.additional_requirements_banks = responseData.data.additional_requirements_banks;
          this.source_of_income_from_rental = responseData.data.source_of_income_from_rental;
        }
      }, error => {
        console.error('Buyer Basic Details ==>', error);
      });
  }

  clickToFinishIcon() {
    if (this.reserved_sale_documents === 1 &&
      this.contracted_sale_documents === 1 &&
      this.if_locally_employed === 1 &&
      this.if_employed_abroad === 1 &&
      this.if_self_employed === 1 &&
      this.additional_requirements_banks === 1 &&
      this.source_of_income_from_rental === 1) {
        this.router.navigate(['/allDocumentSubmittedSuccessfully']);
    } else {
      this.notiService.error('Error!', 'Submit All Required Documents', {
        timeOut: 3000,
        showProgressBar: true,
        pauseOnHover: true,
        clickToClose: true
      }); 
    }
  }
        // ............................reservedSaleDocuments..........................
    uploadConditionalPurchaseAgreement(input) {
        let fileList: FileList = input.target.files;
        console.log(fileList);
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.reservedSaleDocuments._conditionalPurchaseAgreementFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.reservedSaleDocuments.conditionalPurchaseAgreement = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
  
    uploadBuyerInformationSheet(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.reservedSaleDocuments._buyerInformationSheetFilname = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.reservedSaleDocuments.buyerInformationSheet = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadComputationSheet(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.reservedSaleDocuments._computationSheetFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.reservedSaleDocuments.computationSheet = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadHouseSpecificationList(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.reservedSaleDocuments._houseSpecificationListFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.reservedSaleDocuments.houseSpecificationList = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadBuyersGuide(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.reservedSaleDocuments._buyersGuideFilename = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.reservedSaleDocuments.buyersGuide = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    upload5ConvenientBuyerSteps(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.reservedSaleDocuments._5ConvenientBuyerStepsFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.reservedSaleDocuments._5ConvenientBuyerSteps = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadProofOfReservationFeePayment(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.reservedSaleDocuments._proofOfReservationFeePaymentFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.reservedSaleDocuments.proofOfReservationFeePayment = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    upload1stIdOfBuyer(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.reservedSaleDocuments._1stIdOfBuyerFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.reservedSaleDocuments._1stIdOfBuyer = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadDataPrivacyConsent(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.reservedSaleDocuments._dataPrivacyConsentFilename = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.reservedSaleDocuments.dataPrivacyConsent = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadIntentToPurchase(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.reservedSaleDocuments._intentToPurchaseFilename = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.reservedSaleDocuments.intentToPurchase = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadAllReservedSaleDocuments() {
            let formData: FormData = new FormData();
            formData.append('category', this.reservedSaleDocuments.category);
            formData.append('conditionalPurchaseAgreement', this.reservedSaleDocuments.conditionalPurchaseAgreement);
            formData.append('buyerInformationSheet', this.reservedSaleDocuments.buyerInformationSheet);
            formData.append('computationSheet', this.reservedSaleDocuments.computationSheet);
            formData.append('houseSpecificationList', this.reservedSaleDocuments.houseSpecificationList);
            formData.append('buyersGuide', this.reservedSaleDocuments.buyersGuide);
            formData.append('5ConvenientBuyerSteps', this.reservedSaleDocuments._5ConvenientBuyerSteps);
            formData.append('proofOfReservationFeePayment', this.reservedSaleDocuments.proofOfReservationFeePayment);
            formData.append('1stIdOfBuyer', this.reservedSaleDocuments._1stIdOfBuyer);
            formData.append('dataPrivacyConsent', this.reservedSaleDocuments.dataPrivacyConsent);
            formData.append('intentToPurchase', this.reservedSaleDocuments.intentToPurchase);
            this.busy1 = this.userService.uploadAllReservedSaleDocuments(formData).subscribe(respData => {
                if (respData.status === true) {
                    this.getBuyerBasicDetails();
                    this.notiService.success('Success!', respData.msg, {
                        timeOut: 3000,
                        showProgressBar: true,
                        pauseOnHover: true,
                        clickToClose: true
                    });
                } else {
                    this.notiService.error('Error!', respData.msg, {
                        timeOut: 3000,
                        showProgressBar: true,
                        pauseOnHover: true,
                        clickToClose: true
                    });
                }
            }, err => {
                console.error('Server Side Error' + err);
            });
  
        }
        // ............................contractedSaleDocuments.............................
    uploadProofOfIncome(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.contractedSaleDocumentsModel._proofOfIncomeFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.contractedSaleDocumentsModel.proofOfIncome = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadProofOfBilling(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.contractedSaleDocumentsModel._proofOfBillingFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.contractedSaleDocumentsModel.proofOfBilling = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadProofOfCivilStatus(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.contractedSaleDocumentsModel._proofOfCivilStatusFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.contractedSaleDocumentsModel.proofOfCivilStatus = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadProofOfDownpayment(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.contractedSaleDocumentsModel._proofOfDownpaymentFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.contractedSaleDocumentsModel.proofOfDownpayment = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadUnifiedHomeLoanApplication(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.contractedSaleDocumentsModel._unifiedHomeLoanApplicationFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.contractedSaleDocumentsModel.unifiedHomeLoanApplication = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadDeedOfAbsoluteSale(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.contractedSaleDocumentsModel._deedOfAbsoluteSaleFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.contractedSaleDocumentsModel.deedOfAbsoluteSale = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadtINOrbIR1904r(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.contractedSaleDocumentsModel._tINOrbIR1904FileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.contractedSaleDocumentsModel.tINOrbIR1904 = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadrequirementChecklist(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    var reader = new FileReader();
                    this.contractedSaleDocumentsModel._requirementChecklistFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.contractedSaleDocumentsModel.requirementChecklist = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
  
    uploadAllContractedSaleDocuments() {
            let formData: FormData = new FormData();
            formData.append('category', this.contractedSaleDocumentsModel.category);
            formData.append('proofOfIncome', this.contractedSaleDocumentsModel.proofOfIncome);
            formData.append('proofOfBilling', this.contractedSaleDocumentsModel.proofOfBilling);
            formData.append('proofOfCivilStatus', this.contractedSaleDocumentsModel.proofOfCivilStatus);
            formData.append('proofOfDownpayment', this.contractedSaleDocumentsModel.proofOfDownpayment);
            formData.append('unifiedHomeLoanApplication', this.contractedSaleDocumentsModel.unifiedHomeLoanApplication);
            formData.append('deedOfAbsoluteSale', this.contractedSaleDocumentsModel.deedOfAbsoluteSale);
            formData.append('tINOrbIR1904', this.contractedSaleDocumentsModel.tINOrbIR1904);
            formData.append('requirementChecklist', this.contractedSaleDocumentsModel.requirementChecklist);
            this.busy2 = this.userService.uploadAllReservedSaleDocuments(formData).subscribe(respData => {
                if (respData.status === true) {
                    this.getBuyerBasicDetails();
                    this.notiService.success('Success!', respData.msg, {
                        timeOut: 3000,
                        showProgressBar: true,
                        pauseOnHover: true,
                        clickToClose: true
                    });
                } else {
                    this.notiService.error('Error!', respData.msg, {
                        timeOut: 3000,
                        showProgressBar: true,
                        pauseOnHover: true,
                        clickToClose: true
                    });
                }
            }, err => {
                console.error('Server Side Error' + err);
            });
  
        }
        // .................................ifLocallyEmployed..........................
  
    uploadCertificateOfEmployent(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifLocallyEmployedModel._certificateOfEmployentFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifLocallyEmployedModel.certificateOfEmployent = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadLatestITROfBIR1906(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifLocallyEmployedModel._latestITROfBIR1906FileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifLocallyEmployedModel.latestITROfBIR1906 = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadLatest3MonthsPayslips(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        if (this.ifLocallyEmployedModel.latest3MonthsPayslips.length < 3) {
                            this.ifLocallyEmployedModel.latest3MonthsPayslips.push(fileList[0]);
                        } else {
                            this.notiService.warn('Warning !', 'Only 3 Payslip Required', {
                                timeOut: 3000,
                                showProgressBar: true,
                                pauseOnHover: true,
                                clickToClose: true
                            });
                        }
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
  
    removeUploadedPaySlips(index) {
        this.ifLocallyEmployedModel.latest3MonthsPayslips.splice(index, 1);
  
    }
  
    upload2ndIdOfBuyer(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifLocallyEmployedModel._2ndIdOfBuyerFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifLocallyEmployedModel._2ndIdOfBuyer = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    upload1stIdOfSpouse(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifLocallyEmployedModel._1stIdOfSpouseFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifLocallyEmployedModel._1stIdOfSpouse = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    upload2ndIdOfSpouse(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifLocallyEmployedModel._2ndIdOfSpouseFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifLocallyEmployedModel._2ndIdOfSpouse = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    upload1stIdOfCoborrower(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifLocallyEmployedModel._1stIdOfCoborrowerFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifLocallyEmployedModel._1stIdOfCoborrower = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    upload2stIdOfCoborrower(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifLocallyEmployedModel._2ndIdOfCoborrowerFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifLocallyEmployedModel._2ndIdOfCoborrower = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
  
    uploadAllIfLocallyEmployed() {
        let formData: FormData = new FormData();
        formData.append('category', this.ifLocallyEmployedModel.category);
        formData.append('certificateOfEmployent', this.ifLocallyEmployedModel.certificateOfEmployent);
        formData.append('latestITROfBIR1906', this.ifLocallyEmployedModel.latestITROfBIR1906);
        for (let i = 0; i < this.ifLocallyEmployedModel.latest3MonthsPayslips.length; i++) {
            let latest3MonthsPayslipsFileName = this.ifLocallyEmployedModel.latest3MonthsPayslips[i];
            formData.append('latest3MonthsPayslips' + (i + 1), latest3MonthsPayslipsFileName);
        }
        formData.append('2ndIdOfBuyer', this.ifLocallyEmployedModel._2ndIdOfBuyer);
        formData.append('1stIdOfSpouse', this.ifLocallyEmployedModel._1stIdOfSpouse);
        formData.append('2ndIdOfSpouse', this.ifLocallyEmployedModel._2ndIdOfSpouse);
        formData.append('1stIdOfCoborrower', this.ifLocallyEmployedModel._1stIdOfCoborrower);
        formData.append('2ndIdOfCoborrower', this.ifLocallyEmployedModel._2ndIdOfCoborrower);
        this.busy3 = this.userService.uploadAllReservedSaleDocuments(formData).subscribe(respData => {
            if (respData.status === true) {
                this.getBuyerBasicDetails();
                this.notiService.success('Success!', respData.msg, {
                    timeOut: 3000,
                    showProgressBar: true,
                    pauseOnHover: true,
                    clickToClose: true
                });
               
            } else {
                this.notiService.error('Error!', respData.msg, {
                    timeOut: 3000,
                    showProgressBar: true,
                    pauseOnHover: true,
                    clickToClose: true
                });
            }
        }, err => {
            console.error('Server Side Error' + err);
        });
    }
  
    // ................ifEmployedAbroad................................................
  
    uploadSpecialPowerOfAttorneyInfact(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifEmployedAbroadModel._specialPowerOfAttorneyInfactFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifEmployedAbroadModel.specialPowerOfAttorneyInfact = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadPOEAContractAttorneyInfact(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifEmployedAbroadModel._POEAContractAttorneyInfactFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifEmployedAbroadModel._POEAContractAttorneyInfact = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadLatest3MonthsPayslipsAttorneyInfact(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        if (this.ifEmployedAbroadModel.latest3MonthsPayslipsAttorneyInfact.length < 3) {
                            this.ifEmployedAbroadModel.latest3MonthsPayslipsAttorneyInfact.push(fileList[0]);
                        } else {
                            this.notiService.warn('Warning !', 'Only 3 Payslip Required', {
                                timeOut: 3000,
                                showProgressBar: true,
                                pauseOnHover: true,
                                clickToClose: true
                            });
                        }
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
  
    removeUploadedPaySlipsAttorneyInfact(index) {
        this.ifEmployedAbroadModel.latest3MonthsPayslipsAttorneyInfact.splice(index, 1);
  
    }
  
    uploadLatest3MonthsRemitanncesAttorneyInfact(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        if (this.ifEmployedAbroadModel.latest3MonthsRemitanncesAttorneyInfact.length < 3) {
                            this.ifEmployedAbroadModel.latest3MonthsRemitanncesAttorneyInfact.push(fileList[0]);
                        } else {
                            this.notiService.warn('Warning!', 'Only 3 Remitannces slip Required', {
                                timeOut: 3000,
                                showProgressBar: true,
                                pauseOnHover: true,
                                clickToClose: true
                            });
                        }
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
  
    removeLatest3MonthsRemitanncesAttorneyInfact(index) {
        this.ifEmployedAbroadModel.latest3MonthsRemitanncesAttorneyInfact.splice(index, 1);
  
    }
    upload2ndIdOfBuyerAttorneyInfact(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifEmployedAbroadModel._2ndIdOfBuyerAttorneyInfactFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifEmployedAbroadModel._2ndIdOfBuyerAttorneyInfact = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadIdOfBuyerAttorneyInfact(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifEmployedAbroadModel._IdOfBuyerAttorneyInfactFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifEmployedAbroadModel._IdOfBuyerAttorneyInfact = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadIdOfSpouseAttorneyInfact(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifEmployedAbroadModel._idOfSpouseAttorneyInfactFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifEmployedAbroadModel._IdOfBuyerAttorneyInfact = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
  
    upload1stIdOfSpouseAttorneyInfact(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifEmployedAbroadModel._1stIdOfSpouseAttorneyInfactFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifEmployedAbroadModel._1stIdOfSpouseAttorneyInfact = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    upload2ndIdOfSpouseAttorneyInfact(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifEmployedAbroadModel._2ndIdOfSpouseAttorneyInfactFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifEmployedAbroadModel._2ndIdOfSpouseAttorneyInfact = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
  
    upload1stIdOfCoborrowerAttorneyInfact(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifEmployedAbroadModel._1stIdOfCoborrowerAttorneyInfactFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifEmployedAbroadModel._1stIdOfCoborrowerAttorneyInfact = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    upload2ndIdOfCoborrowerAttorneyInfact(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifEmployedAbroadModel._2ndIdOfCoborrowerAttorneyInfactFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifEmployedAbroadModel._2ndIdOfCoborrowerAttorneyInfact = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
  
    uploadIfEmployedAbroad() {
            let formData: FormData = new FormData();
            formData.append('category', this.ifEmployedAbroadModel.category);
            formData.append('specialPowerOfAttorney', this.ifEmployedAbroadModel.specialPowerOfAttorneyInfact);
            formData.append('POEAContract', this.ifEmployedAbroadModel._POEAContractAttorneyInfact);
            for (let i = 0; i < this.ifEmployedAbroadModel.latest3MonthsPayslipsAttorneyInfact.length; i++) {
                let latest3MonthsPayslipsFileName = this.ifEmployedAbroadModel.latest3MonthsPayslipsAttorneyInfact[i];
                formData.append('latest3MonthsPayslips' + (i + 1), latest3MonthsPayslipsFileName);
            }
            for (let i = 0; i < this.ifEmployedAbroadModel.latest3MonthsRemitanncesAttorneyInfact.length; i++) {
                let latest3MonthsRemitanncesFileName = this.ifEmployedAbroadModel.latest3MonthsRemitanncesAttorneyInfact[i];
                formData.append('latest3MonthsRemitannces' + (i + 1), latest3MonthsRemitanncesFileName);
            }
            formData.append('2ndIdOfBuyer', this.ifEmployedAbroadModel._2ndIdOfBuyerAttorneyInfact);
            formData.append('1stIdOfSpouse', this.ifEmployedAbroadModel._1stIdOfSpouseAttorneyInfact);
            formData.append('2ndIdOfSpouse', this.ifEmployedAbroadModel._2ndIdOfSpouseAttorneyInfact);
            formData.append('IdOfBuyerAttorneyInfact', this.ifEmployedAbroadModel._IdOfBuyerAttorneyInfact);
            formData.append('idOfSpouseAttorneyInfact', this.ifEmployedAbroadModel._IdOfSpouseAttorneyInfact);
            formData.append('1stIdOfCoborrower', this.ifEmployedAbroadModel._1stIdOfCoborrowerAttorneyInfact);
            formData.append('2ndIdOfCoborrower', this.ifEmployedAbroadModel._2ndIdOfCoborrowerAttorneyInfact);
            this.busy4 = this.userService.uploadAllReservedSaleDocuments(formData).subscribe(respData => {
                if (respData.status === true) {
                    this.getBuyerBasicDetails();
                    this.notiService.success('Success!', respData.msg, {
                        timeOut: 3000,
                        showProgressBar: true,
                        pauseOnHover: true,
                        clickToClose: true
                    });
                } else {
                    this.notiService.error('Error!', respData.msg, {
                        timeOut: 3000,
                        showProgressBar: true,
                        pauseOnHover: true,
                        clickToClose: true
                    });
                }
            }, err => {
                console.error('Server Side Error' + err);
            });
        }
        // .........................ifSelfEmployed.................................................
    uploadCertificateOfBusinessRegistrationIfSelfEmployed(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifSelfEmployedModel._certificateOfBusinessRegistrationIfSelfEmployedFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifSelfEmployedModel.certificateOfBusinessRegistrationIfSelfEmployed = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadAuditedFinancialStatementIfSelfEmployed(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    var reader = new FileReader();
                    this.ifSelfEmployedModel._auditedFinancialStatementIfSelfEmployedFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifSelfEmployedModel.auditedFinancialStatementIfSelfEmployed = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadLatest6MonthsBankStatementIfSelfEmployed(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifSelfEmployedModel._latest6MonthsBankStatementIfSelfEmployedFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifSelfEmployedModel._latest6MonthsBankStatementIfSelfEmployed = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    upload2ndIdOfBuyerIfSelfEmployed(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifSelfEmployedModel._2ndIdOfBuyerIfSelfEmployedFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifSelfEmployedModel._2ndIdOfBuyerIfSelfEmployed = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    upload1stIdOfSpouseIfSelfEmployed(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifSelfEmployedModel._1stIdOfSpouseIfSelfEmployedFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifSelfEmployedModel._1stIdOfSpouseIfSelfEmployed = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    upload2ndIdOfSpouseIfSelfEmployed(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifSelfEmployedModel._2ndIdOfSpouseIfSelfEmployedFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifSelfEmployedModel._2ndIdOfSpouseIfSelfEmployed = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    upload1stIdOfCoborrowerIfSelfEmployed(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifSelfEmployedModel._1stIdOfCoborrowerIfSelfEmployedFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifSelfEmployedModel._1stIdOfCoborrowerIfSelfEmployed = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    upload_2ndIdOfCoborrowerIfSelfEmployed(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.ifSelfEmployedModel._2ndIdOfCoborrowerIfSelfEmployedFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.ifSelfEmployedModel._2ndIdOfCoborrowerIfSelfEmployed = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
  
    uploadAllIfSelfEmployedDetails() {
            let formData: FormData = new FormData();
            formData.append('category', this.ifSelfEmployedModel.category);
            formData.append('certificateOfBusinessRegistration', this.ifSelfEmployedModel.certificateOfBusinessRegistrationIfSelfEmployed);
            formData.append('auditedFinancialStatement', this.ifSelfEmployedModel.auditedFinancialStatementIfSelfEmployed);
            formData.append('latest6MonthsBankStatement', this.ifSelfEmployedModel._latest6MonthsBankStatementIfSelfEmployed);
            formData.append('2ndIdOfBuyer', this.ifSelfEmployedModel._2ndIdOfBuyerIfSelfEmployed);
            formData.append('1stIdOfSpouse', this.ifSelfEmployedModel._1stIdOfSpouseIfSelfEmployed);
            formData.append('2ndIdOfSpouse', this.ifSelfEmployedModel._2ndIdOfSpouseIfSelfEmployed);
            formData.append('1stIdOfCoborrower', this.ifSelfEmployedModel._1stIdOfCoborrowerIfSelfEmployed);
            formData.append('2ndIdOfCoborrower', this.ifSelfEmployedModel._2ndIdOfCoborrowerIfSelfEmployed);
            this.busy5 = this.userService.uploadAllReservedSaleDocuments(formData).subscribe(respData => {
                if (respData.status === true) {
                    this.getBuyerBasicDetails();
                    this.notiService.success('Success!', respData.msg, {
                        timeOut: 3000,
                        showProgressBar: true,
                        pauseOnHover: true,
                        clickToClose: true
                    });
                } else {
                    this.notiService.error('Error!', respData.msg, {
                        timeOut: 3000,
                        showProgressBar: true,
                        pauseOnHover: true,
                        clickToClose: true
                    });
                }
            }, err => {
                console.error('Server Side Error' + err);
            });
  
        }
        // ..............................additionalRequirementsBanks.................................................
  
    uploadBirthCertificate(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.additionalRequirementsBanksModel._birthCertificateFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.additionalRequirementsBanksModel.birthCertificate = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadAffidavitOfCitizenship(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.additionalRequirementsBanksModel._affidavitOfCitizenshipFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.additionalRequirementsBanksModel.affidavitOfCitizenship = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadOathOfAllegiance(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.additionalRequirementsBanksModel._oathOfAllegianceFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.additionalRequirementsBanksModel.oathOfAllegiance = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadLetterOfUndertaking(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    var reader = new FileReader();
                    this.additionalRequirementsBanksModel._letterOfUndertakingFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.additionalRequirementsBanksModel.letterOfUndertaking = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
  
    uploadAllAdditionalRequirementsBanks() {
            let formData: FormData = new FormData();
            formData.append('category', this.additionalRequirementsBanksModel.category);
            formData.append('birthCertificate', this.additionalRequirementsBanksModel.birthCertificate);
            formData.append('affidavitOfCitizenship', this.additionalRequirementsBanksModel.affidavitOfCitizenship);
            formData.append('oathOfAllegiance', this.additionalRequirementsBanksModel.oathOfAllegiance);
            formData.append('letterOfUndertaking', this.additionalRequirementsBanksModel.letterOfUndertaking);
            this.busy6 = this.userService.uploadAllReservedSaleDocuments(formData).subscribe(respData => {
                if (respData.status === true) {
                    this.getBuyerBasicDetails();
                    this.notiService.success('Success!', respData.msg, {
                        timeOut: 3000,
                        showProgressBar: true,
                        pauseOnHover: true,
                        clickToClose: true
                    });
                } else {
                    this.notiService.error('Error!', respData.msg, {
                        timeOut: 3000,
                        showProgressBar: true,
                        pauseOnHover: true,
                        clickToClose: true
                    });
                }
            }, err => {
                console.error('Server Side Error' + err);
            });
  
        }
        // ..................................sourceOfIncomeFromRental...............................
  
    uploadLeaseContract(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.sourceOfIncomeFromRentalModel._leaseContractFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.sourceOfIncomeFromRentalModel.leaseContract = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
    uploadPhotocopyOfTitle(input) {
        let fileList: FileList = input.target.files;
        if (fileList[0].type === 'application/pdf' || fileList[0].type === 'image/jpeg' || fileList[0].type === 'image/png') {
            if (fileList.length > -1) {
                if (fileList && fileList[0]) {
                    this.sourceOfIncomeFromRentalModel._photocopyOfTitleFileName = fileList[0].name;
                    if (((fileList[0].type).indexOf('application/pdf') > -1) || ((fileList[0].type).indexOf('image/jpeg') > -1) || ((fileList[0].type).indexOf('image/png') > -1)) {
                        this.sourceOfIncomeFromRentalModel.photocopyOfTitle = fileList[0];
                    }
                }
            }
        } else {
            this.notiService.error('Error!', 'Upload PDF of Image Format File Only!! ', {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
        }
    }
  
    uploadAllSourceOfIncomeFromRental() {
        let formData: FormData = new FormData();
        formData.append('category', this.sourceOfIncomeFromRentalModel.category);
        formData.append('leaseContract', this.sourceOfIncomeFromRentalModel.leaseContract);
        formData.append('photocopyOfTitle', this.sourceOfIncomeFromRentalModel.photocopyOfTitle);
        this.busy7 = this.userService.uploadAllReservedSaleDocuments(formData).subscribe(respData => {
            if (respData.status === true) {
                this.getBuyerBasicDetails();
                if (this.reserved_sale_documents === 1 &&
                    this.contracted_sale_documents === 1 &&
                    this.if_locally_employed === 1 &&
                    this.if_employed_abroad === 1 &&
                    this.if_self_employed === 1 &&
                    this.additional_requirements_banks === 1 &&
                    this.source_of_income_from_rental === 1) {
                      this.router.navigate(['/allDocumentSubmittedSuccessfully']);
                  }
                this.notiService.success('Success!', respData.msg, {
                    timeOut: 3000,
                    showProgressBar: true,
                    pauseOnHover: true,
                    clickToClose: true
                });
            } else {
                this.notiService.error('Error!', respData.msg, {
                    timeOut: 3000,
                    showProgressBar: true,
                    pauseOnHover: true,
                    clickToClose: true
                });
            }
        }, err => {
            console.error('Server Side Error' + err);
        });
  
    }
  
}