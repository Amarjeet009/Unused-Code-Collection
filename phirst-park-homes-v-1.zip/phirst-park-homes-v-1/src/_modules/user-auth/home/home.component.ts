import { Component, OnInit, ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import { UserService } from '../../../_services/user.service';
import { NotificationsService } from 'angular2-notifications';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})



export class HomeComponent implements OnInit, AfterViewInit {
  status: any;
  userModel = {
    'userId': localStorage.getItem('emailId')
  };
  firstName = '----';
  middleName = '----';
  lastName = '----';
  getbuyerRespData: any;
  public _payment_status: any;
  public is_individual_buyer: any;
  public propertyListData: any;
  doc_status: any;
  imgURL = '../../assets/images/profile.png';
  userPropertyId: any;
  userPropertyStatus: any;
  isSelectedDivVisible = false;
  constructor(private userService: UserService,
    private notiService: NotificationsService) {  }

  ngOnInit() {
    window.scrollTo(500, 0);
    this.userService.getBuyerProperty().subscribe(respData => {
      this.propertyListData = respData.data;
    });
    this._payment_status = this.userService.getForBuyerPropertiesPaymentOption();
    this.userService.getBuyerBasicDetails(this.userModel).subscribe(responseData => {
      if (responseData.status === true) {
        this.firstName = responseData.data.first_name;
        this.middleName = responseData.data.middle_name;
        this.lastName = responseData.data.last_name;
        this.is_individual_buyer = responseData.data.is_individual_buyer;
        this.doc_status = responseData.data.doc_status;
        localStorage.setItem('userId', responseData.data.user_id);
        if (responseData.data.profile_pic !== 'null') {
          this.imgURL = responseData.data.profile_pic;
        }
        localStorage.setItem('myid',  responseData.data.id); //set id to localstorage  => home.component.ts
      }
    }, error => {
      console.error('Buyer Basic Details ==>', error);
    });
  }
  onClickGetUserData(userData: any) {
   const _data = JSON.parse(userData);
   if (_data) {
    this.userPropertyId = _data.property_id;
    this.userPropertyStatus = _data.status;
    this.isSelectedDivVisible = true;
   } else {
     this.isSelectedDivVisible = false;
   }

  }
  ngAfterViewInit() { }

  uploadProfilePic(input) {
    let fileList: FileList = input.target.files;
    if (fileList.length > -1) {
      if (fileList && fileList[0]) {
        var reader = new FileReader();
        if (((fileList[0].type).indexOf('image/') > -1)) {
          let formData: FormData = new FormData();
          formData.append('ID',  fileList[0]);
          this.userService.uploadProfilePic(formData).subscribe(respData => {
            if(respData.status === true) {
              this.imgURL = respData.data;
              this.notiService.success('Success!', respData.msg, {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
            } else {
              this.notiService.error('Error!', respData.msg, {
                timeOut: 3000,
                showProgressBar: true,
                pauseOnHover: true,
                clickToClose: true
            });
            }
          });
        }
      } else {
        this.notiService.error('Error!', 'Upload Image Only', {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
      });
      }
    }
  }

}
