import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { UserService } from '../../../_services/user.service';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-account-detail',
  templateUrl: './account-detail.component.html',
  styleUrls: ['./account-detail.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AccountDetailComponent implements OnInit {
 public dataUrl: any;
 public propertyListData: any;
 public unit_id: any = '---';
 public dataCompareById: any;
 public ImageCdn = 'http://dr2myglbq65g4.cloudfront.net/HouseTypeImage/';
 public property_name: any = '---';
 public unit_price: any = 0;
 public status: any = '---';
 public userId: any = '---';
 public lotArea: any = '---';
 public floorArea: any = '---';
 public netContractPrice: any = 0.00;
 public downpayment: any = 0.00;
 public takeOutBalance: any = 0.00;
 public batch: any = '---';
 public projectID: any = '---';
 public houseConstructionStatus: any = '---';
 public unitCode: any = '---';
 public busy: Subscription;
  constructor(private userService: UserService, private route: ActivatedRoute) { }

  ngOnInit() {
    window.scrollTo(500, 0);
    this.userId = localStorage.getItem('userId');
    this.dataUrl = this.route.params.subscribe(params => {
      this.dataCompareById = params.id;
    });

  this.busy =  this.userService.getBuyerPropertiesDetails({'userId': this.userId }).subscribe(respData => {
      if (respData.status === true) {
        this.propertyListData = respData.data;
        for (let i = 0; i < this.propertyListData.length; i++) {
          if (this.propertyListData[i].unitNumber === this.dataCompareById) {
            this.unit_id = this.propertyListData[i].unitNumber;
            this.property_name = this.propertyListData[i].unitType;
            this.unit_price = this.propertyListData[i].unitPrice;
            this.status = this.propertyListData[i].unitStatus;
            this.lotArea = this.propertyListData[i].lotArea;
            this.floorArea = this.propertyListData[i].floorArea;
            this.batch = this.propertyListData[i].batch;
            this.projectID = this.propertyListData[i].projectID;
            this.unitCode = this.propertyListData[i].unitCode;
            this.netContractPrice =  this.propertyListData[i].paymentDetails['netContractPrice'];
            this.downpayment = this.propertyListData[i].paymentDetails['downpayment'];
            this.takeOutBalance = this.propertyListData[i].paymentDetails['takeOutBalance'];
            this.houseConstructionStatus = this.propertyListData[i].houseConstructionStatus;
          }
        }
      }
    });
  }

}
