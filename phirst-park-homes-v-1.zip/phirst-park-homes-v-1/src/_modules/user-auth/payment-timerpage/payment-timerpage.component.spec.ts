import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentTimerpageComponent } from './payment-timerpage.component';

describe('PaymentTimerpageComponent', () => {
  let component: PaymentTimerpageComponent;
  let fixture: ComponentFixture<PaymentTimerpageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentTimerpageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentTimerpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
