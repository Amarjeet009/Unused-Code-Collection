import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { UserService } from 'src/_services/user.service';
import { Subscription } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { Config } from 'src/_config/config';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { PaymentModel } from 'src/_models/payment.model';
import { NotificationsService } from 'angular2-notifications';


@Component({
    selector: 'app-payment-timerpage',
    templateUrl: './payment-timerpage.component.html',
    styleUrls: ['./payment-timerpage.component.css']
})
export class PaymentTimerpageComponent implements OnInit {
    public headers: HttpHeaders = new HttpHeaders();
    public intervalSet = false;
    public buyer_id: any;
    public property_id: any;
    public property_name: any;
    public hours: any;
    public minutes: any;
    public seconds: any;
    public resv_fee: number = 0;
    public status: any;
    public busy: Subscription;
    public busy1: Subscription;
    public isDivVisible = false;
    public resDataMsg: any;
    public makePaymentPayload = {
        'propertyId': '',
        'amount': 0
    };
    payFormCcard = {};
    paymentModel: PaymentModel = new PaymentModel();
    paymentUrl: string;
    dataUrl: any;
    dataCompareById: any;
    propertyListData: any;
    initiated_time: any;
    penalty: number = 0;
    @ViewChild('clickToPayButton') clickToPayButton: ElementRef;
    constructor(
        private userService: UserService,
        private notiService: NotificationsService,
        private route: ActivatedRoute) { }

    ngOnInit() {
        window.scrollTo(500, 0);
        this.dataUrl = this.route.params.subscribe(params => {
            this.dataCompareById = params.id;
        });
        this.busy = this.userService.getBuyerProperty().subscribe(respData => {
            this.propertyListData = respData.data;
            if (respData.status === true) {
                for (let i = 0; i < this.propertyListData.length; i++) {
                    if (this.propertyListData[i].property_id === this.dataCompareById) {
                        this.status = this.propertyListData[i].status;
                        this.property_id = this.propertyListData[i].property_id;
                        this.resv_fee = this.propertyListData[i].resv_fee;
                        this.penalty = this.propertyListData[i].penalty;
                        let initiated_time = new Date(this.propertyListData[i].initiated_time);
                        let paymentInitDate_: Date = new Date(initiated_time.setHours(initiated_time.getHours() + 48));
                        let interval = window.setInterval(() => {
                        //  let today_: Date = new Date();                        
                        let today_: Date = new Date(new Date().toLocaleString('en-US', {timeZone: this.userService.currentDateValue}));
                        
                          if (paymentInitDate_ > today_) {
                            var diffDatesMS_ = Math.abs(paymentInitDate_.getTime() - today_.getTime());
                            this.hours = Math.floor((diffDatesMS_ % (1000 * 60 * 60 * 48)) / (1000 * 60 * 60));
                            this.minutes = Math.floor((diffDatesMS_ % (1000 * 60 * 60)) / (1000 * 60));
                            this.seconds = Math.floor((diffDatesMS_ % (1000 * 60)) / 1000);
                          } else {
                              window.clearInterval(interval);
                          }
                        });
                    }
                }
            } else {
                this.resDataMsg = respData.msg;
            }
        });
    }

    getHeader() {
        this.headers = this.headers
            .append('Accept', 'application/x-www-form-urlencoded')
            .append('Content-Type', 'application/x-www-form-urlencoded')
            .append('Access-Control-Allow-Origin', '*');
        return this.headers;
    }
    buyerMakeReservePayment() {
        this.makePaymentPayload.propertyId = this.property_id;
        this.makePaymentPayload.amount = this.resv_fee + this.penalty;
        this.busy1 = this.userService.buyerMakeReservePayment(this.makePaymentPayload).subscribe(respData => {
            if (respData.status === true) {
                this.paymentUrl = respData.data.url;
                this.paymentModel.merchantId = Config.pesopay.merchantId;
                this.paymentModel.successUrl = Config.pesopay.successUrl;
                this.paymentModel.failUrl = Config.pesopay.failUrl;
                this.paymentModel.cancelUrl = Config.pesopay.cancelUrl;
                this.paymentModel.amount = respData.data.form.amount;
                this.paymentModel.orderRef = respData.data.form.orderRef;
                this.paymentModel.currCode = respData.data.form.currCode;
                this.paymentModel.mpsMode = respData.data.form.mpsMode;
                this.paymentModel.payType = respData.data.form.payType;
                this.paymentModel.lang = respData.data.form.lang;
                this.paymentModel.payMethod = respData.data.form.payMethod;
                this.paymentModel.secureHash = respData.data.form.secureHash;
                    setTimeout(() => {
                        this.clickToPayButton.nativeElement.click();
                    }, 200);
            } else if (respData.status === false) {
                this.notiService.error('Error!', respData.msg, {
                    timeOut: 3000,
                    showProgressBar: true,
                    pauseOnHover: true,
                    clickToClose: true
                });
            }
        });
    }
}
