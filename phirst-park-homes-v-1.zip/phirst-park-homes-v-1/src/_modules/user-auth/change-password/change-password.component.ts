import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MustMatch } from '../../../_helpers/must-match.validator';
import { UserService } from '../../../_services/user.service';
import { NotificationsService } from 'angular2-notifications';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  public inputType = 'password';
  public visible = false;
  changePasswordForm: FormGroup;
  submitted = false;
  public showStyle = {
    marginLeft: '0%',
    fontSize: '14px',
    color: 'blue',
    textDecoration: 'underline'
  };
  public hideStyle = {
    marginLeft: '0%',
    fontSize: '14px',
    color: 'red',
    textDecoration: 'underline'
  };
  public busy: Subscription;
  constructor(
    private formBuilder: FormBuilder,
    private userService: UserService,
    private changeDetectorRef: ChangeDetectorRef,
    private notiService: NotificationsService,
    private router: Router) { }

  ngOnInit() {
    window.scrollTo(500, 0);
    this.changePasswordForm = this.formBuilder.group({
      userId: [localStorage.getItem('emailId')],
      password: ['', Validators.required],
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, {
        validator: MustMatch('newPassword', 'confirmPassword')
      });
  }

  // convenience getter for easy access to form fields
  get f() { return this.changePasswordForm.controls; }

  show() {
    this.inputType = 'text';
    this.visible = true;
    this.changeDetectorRef.markForCheck();
  }

  hide() {
    this.inputType = 'password';
    this.visible = false;
    this.changeDetectorRef.markForCheck();
  }


  onSubmitChangePassword() {
    this.submitted = true;
    //  stop here if form is invalid
    if (this.changePasswordForm.invalid) {
      return;
    }
   this.busy =  this.userService.changeUserPassword(this.changePasswordForm.value).subscribe(respData => {
      if (respData.status === true) {
        this.router.navigate(['/home']);
        this.notiService.success('Success!', respData.msg, {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
      } else {
        this.notiService.error('Error!', respData.msg, {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
      }
    });

  }
}
