import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { UpdateUserModel } from '../../../_models/update.user.model';
import { NotificationsService } from 'angular2-notifications';
import { UserService } from '../../../_services/user.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbDateAdapter, NgbDateNativeAdapter, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import * as $ from 'jquery';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css'],
  providers: [{ provide: NgbDateAdapter, useClass: NgbDateNativeAdapter }]
})
export class UpdateProfileComponent implements OnInit {
  public emailAddress: string;
  public updateUserModel: UpdateUserModel = new UpdateUserModel();
  public busy: Subscription;
  public busy1: Subscription;
  maxDate: Date;
  userModel = {
    'userId': localStorage.getItem('emailId')
  };

  public firstName: string;
  public middleName: string;
  public lastName: string;
  public mobileNo: string;
  public emailId: string;
  public phoneNo: string;
  updateUserForm: FormGroup;
  _updateUserModel: UpdateUserModel = new UpdateUserModel();
  isBuyerPersonalInformation = false;
  isAttorneyInFactCitizenshipVisible = false;
  isAttorneyInFactRelationToBuyerVisible = false;
  isSpouseAttorneyInFactCitizenshipVisible = false;
  isSpouseAttorneyInFactRelationToBuyerVisible = false;
  isASICitizenshipVisible = false;
  iscSpouseCitizenshipVisible = false;
  buyerDetailsLength: any;
  isContactPersonInformationVisible = false;
  isReferralVisible = false;
  isReferralVisible2 = false;
  isCurrentHomeOwnershipVisible = false;
  isSubmitButtonVisible = false;
  _isIndividualBuyer: number;
  submitted = false;
  closeResult: string;

  @ViewChild('clickToModalButton') clickToModalButton: ElementRef;
  constructor(
    private notiService: NotificationsService,
    private userService: UserService,
    private router: Router,
    private formBuilder: FormBuilder,
    private modalService: NgbModal) {
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
  }
  ngOnInit() {
    window.scrollTo(500, 0);
    this.emailAddress = localStorage.getItem('emailId');
    this.getInitFormStr();
    this.getBuyerDetails();
  }
  getInitFormStr() {
    this.updateUserForm = this.formBuilder.group({
      buyerID: [''],
      buyerType: [''],
      isIndividualBuyer: [''],
      buyerDocStatus: [''],
      buyerPersonalInformation: this.formBuilder.group({
        suffix: ['', Validators.required],
        firstName: ['', Validators.required],
        middleName: ['', Validators.required],
        lastName: ['', Validators.required],
        emailId: ['', Validators.required],
        gender: ['', Validators.required],
        civilStatus: [''],
        DOB: ['', Validators.required],
        birthplace: [''],
        numberOfChildren: [''],
        citizenship: [''],
        taxIdentificationNumber: ['', Validators.required],
        typeOfValidId: [''],
        idNo: ['']
      }),
      buyerContactInformation: this.formBuilder.group({
        residentialAddress: ['', Validators.required],
        residentailZip: [''],
        otherAddress: ['', Validators.required],
        otherZip: [''],
        mobile: ['', Validators.required],
        phone: ['']
      }),
      buyerEmploymentInformation: this.formBuilder.group({
        employmentType: ['', Validators.required],
        specificEmployement: ['', Validators.required],
        employerOrBusinessName: ['', Validators.required],
        employerOrBusinessAddress: ['', Validators.required],
        employerPhone: ['', Validators.required],
        employerMobile: [''],
        employerEmailAddress: [''],
        occupationTitle: ['', Validators.required],
        occupationRank: [''],
        yearsOfEmployment: ['', Validators.required]
      }),
      buyerAttornyInfo: this.formBuilder.group({
        attorneyInFactFirstName: ['', Validators.required],
        attorneyInFactLastName: ['', Validators.required],
        attorneyInFactSuffixName: [''],
        attorneyInFactGender: ['', Validators.required],
        attorneyInFactCivilStatus: ['', Validators.required],
        attorneyInFactMiddleName: ['', Validators.required],
        attorneyInFactBirthdate: ['', Validators.required],
        attorneyInFactCitizenship: [''],
        attorneyInFactTypeOfValidId: [''],
        attorneyInFactIdNo: [''],
        attorneyInFactMobile: ['', Validators.required],
        attorneyInFactPhone: [''],
        attorneyInFactEmailAddress: ['', Validators.required],
        attorneyInFactResidentialAddress: ['', Validators.required],
        attorneyInFactZipCode: [''],
        attorneyInFactEmployment: [''],
        attorneyInFactRelationToBuyer: ['']
      }),
      spousePersonalInformation: this.formBuilder.group({
        spouseFirstName: ['', Validators.required],
        spouseMiddleName: ['', Validators.required],
        spouseLastName: ['', Validators.required],
        spouseSuffixName: [''],
        spouseGender: ['', Validators.required],
        spouseBirthDate: ['', Validators.required],
        spouseBirthPlace: [''],
        spouseCitizenship: ['', Validators.required],
        spouseNoOfChildren: [''],
        spouseTaxIdentificationNo: [''],
        spouseTypeOfValidId: [''],
        spouseIdNo: [''],
        spousePhone: ['', Validators.required],
        spouseMobile: [''],
        spouseEmailAddress: ['']
      }),
      spouseEmploymentInformation: this.formBuilder.group({
        spouseEmploymentType: ['', Validators.required],
        spouseSpecificEmployement: ['', Validators.required],
        spouseEmployerOrBusinessName: ['', Validators.required],
        spouseEmployerOrBusinessAddress: ['', Validators.required],
        spouseEmployerPhone: ['', Validators.required],
        spouseEmployerMobile: [''],
        spouseEmployerEmailAddress: [''],
        spouseOccupationTitle: ['', Validators.required],
        spouseOccupationRank: [''],
        spouseYearsOfEmployment: ['', Validators.required]
      }),
      spouseAttorneyInfactInformation: this.formBuilder.group({
        spouseAttorneyInFactFirstName: [''],
        spouseAttorneyInFactMiddleName: [''],
        spouseAttorneyInFactLastName: [''],
        spouseAttorneyInFactSuffixName: [''],
        spouseAttorneyInFactGender: [''],
        spouseAttorneyInFactCivilStatus: [''],
        spouseAttorneyInFactBirthdate: [''],
        spouseAttorneyInFactCitizenship: [''],
        spouseAttorneyInFactTypeOfValidId: [''],
        spouseAttorneyInFactIdNo: [''],
        spouseAttorneyInFactMobile: [''],
        spouseAttorneyInFactPhone: [''],
        spouseAttorneyInFactEmailAddress: [''],
        spouseAttorneyInFactResidentialAddress: [''],
        spouseAttorneyInFactZipCode: [''],
        spouseAttorneyInFactEmployment: [''],
        spouseAttorneyInFactRelationToBuyer: ['']
      }),
      nIBuyerBusinessInformation: this.formBuilder.group({
        nIBNameOfBusiness: ['', Validators.required],
        nIBNatureOfBusiness: [''],
        nIBYearsInOperation: ['', Validators.required],
        nIBBusinessType: ['', Validators.required],
        nIBContactNo: ['', Validators.required],
        nIBEmailAddress: ['', Validators.required],
        nIBTaxIdentificationNo: ['', Validators.required],
        nIBSecRegistrationNo: ['', Validators.required],
        nIBSssNo: [''],
        nIBPrincipalOfficeAddress: ['', Validators.required],
        nIBPrincipalOfficeAddressZipCode: [''],
        nIBOtherAddress: [''],
        nIBOtherAddressZipCode: ['']
      }),
      authorisedSignatoryInformation: this.formBuilder.group({
        aSIFirstName: ['', Validators.required],
        aSIMiddleName: ['', Validators.required],
        aSILastName: ['', Validators.required],
        aSISuffixName: [''],
        aSIGender: [''],
        aSICivilStatus: [''],
        aSIBirthDate: [''],
        aSICitizenship: [''],
        aSIDesignation: ['', Validators.required],
        aSItaxIdentificationNo: [''],
        aSITypeOfValidId: [''],
        aSIIdNo: [''],
        aSIMobile: ['', Validators.required],
        aSIOfficePhoneNo: [''],
        aSIfaxNo: [''],
        aSIEmailAddress: ['', Validators.required],
        aSIAddress: ['', Validators.required],
        aSIZipCode: ['']
      }),
      contactPersonInformation: this.formBuilder.group({
        cPIFirstName: ['', Validators.required],
        cPIMiddleName: ['', Validators.required],
        cPILastName: ['', Validators.required],
        cPISuffixName: [''],
        cPIGender: [''],
        cPICivilStatus: [''],
        cPIBirthDate: [''],
        cPICitizenship: [''],
        cPIDesignation: ['', Validators.required],
        cPItaxIdentificationNo: [''],
        cPITypeOfValidId: [''],
        cPIIdNo: [''],
        cPIMobile: ['', Validators.required],
        cPIOfficePhoneNo: [''],
        cPIfaxNo: [''],
        cPIEmailAddress: ['', Validators.required],
        cPIAddress: ['', Validators.required],
        cPIZipCode: ['']
      }),
      profileInformationForm: this.formBuilder.group({
        knowAboutProject: [''],
        ifKnowAboutProjectIsReferral: [''],
        purposeOfBuying: [''],
        ifPurposeOfBuyingIsInvestment: [''],
        currentHomeOwnership: [''],
        lengthOfStay: [''],
        monthlyHouseholdIncomeBuyer: [''],
        monthlyHouseholdIncomeSpouse: [''],
        followupPreferredDays: [''],
        followupPreferredTime: [''],
        followupContactNo: [''],
        followupContactNoType: [''],
        preferredMailingAdddress: [''],
        preferredMailingAdddressType: ['']
      }),
      accountInformation: this.formBuilder.group({
        inTheNameOfType: [''],
        inTheNameOf: [''],
        marriedTo: [''],
        spouses: [''],
        coOwners: [''],
        others: ['']
      }),
    });
  }
  getBuyerDetails() {
    this.userService.getBuyerDetails(this.userModel).subscribe(responseData => {
      this.buyerDetailsLength = responseData;
      if (this.buyerDetailsLength && responseData.statusCode === 200) {
        delete responseData['$class'];
        this._updateUserModel.buyerID = responseData.buyerID;
        this._updateUserModel.buyerType = responseData.buyerType;
        this._updateUserModel.isIndividualBuyer = responseData.isIndividualBuyer;
        this._updateUserModel.buyerDocStatus = responseData.buyerDocStatus;
        delete responseData.buyerPersonalInformation['$class'];
        this._updateUserModel.buyerPersonalInformation = responseData.buyerPersonalInformation;
        delete responseData.buyerContactInformation['$class'];
        delete responseData.buyerContactInformation['countryCode'];
        this._updateUserModel.buyerContactInformation = responseData.buyerContactInformation;
        delete responseData.buyerEmploymentInformation['$class'];
        this._updateUserModel.buyerEmploymentInformation = responseData.buyerEmploymentInformation;
        delete responseData.buyerAttornyInfo['$class'];
        this._updateUserModel.buyerAttornyInfo = responseData.buyerAttornyInfo;
        delete responseData.individualBuyerSpouseInfo['$class'];
        this._updateUserModel.spousePersonalInformation = responseData.individualBuyerSpouseInfo.spousePersonalInformation;
        delete responseData.individualBuyerSpouseInfo.spousePersonalInformation['$class'];
        this._updateUserModel.spouseEmploymentInformation = responseData.individualBuyerSpouseInfo.spouseEmploymentInformation;
        delete responseData.individualBuyerSpouseInfo.spouseEmploymentInformation['$class'];
        this._updateUserModel.spouseAttorneyInfactInformation = responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation;
        delete responseData.individualBuyerSpouseInfo.spouseAttorneyInfactInformation['$class'];
        delete responseData.nonIndividualBuyer['$class'];
        this._updateUserModel.nIBuyerBusinessInformation = responseData.nonIndividualBuyer.nIBuyerBusinessInformation;
        delete responseData.nonIndividualBuyer.nIBuyerBusinessInformation['$class'];
        this._updateUserModel.authorisedSignatoryInformation = responseData.nonIndividualBuyer.authorisedSignatoryInformation;
        delete responseData.nonIndividualBuyer.authorisedSignatoryInformation['$class'];
        this._updateUserModel.contactPersonInformation = responseData.nonIndividualBuyer.contactPersonInformation;
        delete responseData.nonIndividualBuyer.contactPersonInformation['$class'];
        delete responseData.nonIndividualBuyer.contactPersonInformation['countryCode'];
        this._updateUserModel.profileInformationForm = responseData.profileInformationForm;
        delete responseData.profileInformationForm['$class'];
        this._updateUserModel.accountInformation = responseData.accountInformation;
        delete responseData.accountInformation['$class'];
        delete responseData.seller['$class'];
        this.updateUserForm.setValue(this._updateUserModel);
      }
    }, error => {
      console.log('Buyer Full Details' + error);
    }, () => { });
  }

  get f() {
    return (this.updateUserForm.get('accountInformation'))['controls'];
    // return (this.updateUserForm.get('accountInformation') as FormArray).controls;
  }
  get f1() {
    return (this.updateUserForm.get('buyerPersonalInformation'))['controls'];
    // return (this.updateUserForm.get('buyerPersonalInformation') as FormArray).controls;
  }
  get f2() {
    return (this.updateUserForm.get('buyerContactInformation'))['controls'];
  }
  get f3() {
    return (this.updateUserForm.get('buyerEmploymentInformation'))['controls'];
  }
  get f4() {
    return (this.updateUserForm.get('buyerAttornyInfo'))['controls'];
  }
  get f5() {
    return (this.updateUserForm.get('spousePersonalInformation'))['controls'];
  }
  get f6() {
    return (this.updateUserForm.get('spouseEmploymentInformation'))['controls'];
  }
  get f7() {
    return (this.updateUserForm.get('nIBuyerBusinessInformation'))['controls'];
  }
  get f8() {
    return (this.updateUserForm.get('authorisedSignatoryInformation'))['controls'];
  }
  get f9() {
    return (this.updateUserForm.get('contactPersonInformation'))['controls'];
  }

  clickBuyerPersonalInformation(event: any) {
    if (event === 'Others') {
      this.isBuyerPersonalInformation = true;
    } else {
      this.isBuyerPersonalInformation = false;
    }
  }
  clickAttorneyInFactCitizenship(event: any) {
    if (event === 'Others') {
      this.isAttorneyInFactCitizenshipVisible = true;
    } else {
      this.isAttorneyInFactCitizenshipVisible = false;
    }
  }
  clickToSpouseCitizenship(event: any) {
    if (event === 'Others') {
      this.iscSpouseCitizenshipVisible = true;
    } else {
      this.iscSpouseCitizenshipVisible = false;
    }
  }
  clickContactPersonInformation(event: any) {
    if (event === 'Others') {
      this.isContactPersonInformationVisible = true;
    } else {
      this.isContactPersonInformationVisible = false;
    }
  }
  clickAttorneyInFactRelationToBuyer(event: any) {
    if (event === 'others') {
      this.isAttorneyInFactRelationToBuyerVisible = true;
    } else {
      this.isAttorneyInFactRelationToBuyerVisible = false;
    }
  }
  clickSpouseAttorneyInFactCitizenship(event: any) {
    if (event === 'others') {
      this.isSpouseAttorneyInFactCitizenshipVisible = true;
    } else {
      this.isSpouseAttorneyInFactCitizenshipVisible = false;
    }
  }
  clickSpouseAttorneyInFactRelationToBuyer(event: any) {
    if (event === 'others') {
      this.isSpouseAttorneyInFactRelationToBuyerVisible = true;
    } else {
      this.isSpouseAttorneyInFactRelationToBuyerVisible = false;
    }
  }
  clickASICitizenship(event: any) {
    if (event === 'others') {
      this.isASICitizenshipVisible = true;
    } else {
      this.isASICitizenshipVisible = false;
    }
  }

  clickToShowReferralDiv(event: any) {
    if (event === 'Referral') {
      this.isReferralVisible = true;
      this.isReferralVisible2 = false;
    } else if (event === 'OtherSourceSpecify') {
      this.isReferralVisible2 = true;
      this.isReferralVisible = false;
    } else {
      this.isReferralVisible = false;
      this.isReferralVisible2 = false;
    }
  }

  clickCurrentHomeOwnership(event: any) {
    if (event === 'Others') {
      this.isCurrentHomeOwnershipVisible = true;
    } else {
      this.isCurrentHomeOwnershipVisible = false;
    }
  }

  updateBuyerDetails() {
    this.submitted = true;
    // stop here if form is invalid
    if (!this.updateUserForm.valid) {
      window.scrollTo(30, 0);
      setTimeout(() => {
        this.clickToModalButton.nativeElement.click();
      });
      return;
    }

    if (this.updateUserForm.get('buyerPersonalInformation').get('DOB').value === "NaN/NaN/NaN") {
      this.updateUserForm.patchValue({ buyerPersonalInformation: { DOB: null } });
    } else {
      let date = new Date(this.updateUserForm.get('buyerPersonalInformation').get('DOB').value);
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let dt = date.getDate();
      this.updateUserForm.patchValue({ buyerPersonalInformation: { DOB: month + '/' + dt + '/' + year } });
    }
    if (this.updateUserForm.get('buyerAttornyInfo').get('attorneyInFactBirthdate').value === "NaN/NaN/NaN") {
      this.updateUserForm.patchValue({ buyerAttornyInfo: { attorneyInFactBirthdate: null } });
    } else {
      let date1 = new Date(this.updateUserForm.get('buyerAttornyInfo').get('attorneyInFactBirthdate').value);
      let year1 = date1.getFullYear();
      let month1 = date1.getMonth() + 1;
      let dt1 = date1.getDate();
      this.updateUserForm.patchValue({ buyerAttornyInfo: { attorneyInFactBirthdate: month1 + '/' + dt1 + '/' + year1 } });
    }
    if (this.updateUserForm.get('spousePersonalInformation').get('spouseBirthDate').value === "NaN/NaN/NaN") {
      this.updateUserForm.patchValue({ spousePersonalInformation: { spouseBirthDate: null } });
    } else {
      let date3 = new Date(this.updateUserForm.get('spousePersonalInformation').get('spouseBirthDate').value);
      let year3 = date3.getFullYear();
      let month3 = date3.getMonth() + 1;
      let dt3 = date3.getDate();
      this.updateUserForm.patchValue({ spousePersonalInformation: { spouseBirthDate: month3 + '/' + dt3 + '/' + year3 } });
    }

    if (this.updateUserForm.get('spouseAttorneyInfactInformation').get('spouseAttorneyInFactBirthdate').value === "NaN/NaN/NaN") {
      this.updateUserForm.patchValue({ spouseAttorneyInfactInformation: { spouseAttorneyInFactBirthdate: '' } });
    } else {
      let date4 = new Date(this.updateUserForm.get('spouseAttorneyInfactInformation').get('spouseAttorneyInFactBirthdate').value);
      let year4 = date4.getFullYear();
      let month4 = date4.getMonth() + 1;
      let dt4 = date4.getDate();
      this.updateUserForm.patchValue({ spouseAttorneyInfactInformation: { spouseAttorneyInFactBirthdate: month4 + '/' + dt4 + '/' + year4 } });
    }
    if (this.updateUserForm.get('authorisedSignatoryInformation').get('aSIBirthDate').value === "NaN/NaN/NaN") {
      this.updateUserForm.patchValue({ authorisedSignatoryInformation: { aSIBirthDate: null } });
    } else {
      let date5 = new Date(this.updateUserForm.get('authorisedSignatoryInformation').get('aSIBirthDate').value);
      let year5 = date5.getFullYear();
      let month5 = date5.getMonth() + 1;
      let dt5 = date5.getDate();
      this.updateUserForm.patchValue({ authorisedSignatoryInformation: { aSIBirthDate: month5 + '/' + dt5 + '/' + year5 } });
    }

    if (this.updateUserForm.get('contactPersonInformation').get('cPIBirthDate').value === "NaN/NaN/NaN") {
      this.updateUserForm.patchValue({ contactPersonInformation: { cPIBirthDate: null } });
    } else {
      let date6 = new Date(this.updateUserForm.get('contactPersonInformation').get('cPIBirthDate').value);
      let year6 = date6.getFullYear();
      let month6 = date6.getMonth() + 1;
      let dt6 = date6.getDate();
      this.updateUserForm.patchValue({ contactPersonInformation: { cPIBirthDate: month6 + '/' + dt6 + '/' + year6 } });
    }
    this.busy1 = this.userService.getUpdateBuyerDetails(this.updateUserForm.value).subscribe(resp => {
      if (resp.statusCode === 200) {
        this.isSubmitButtonVisible = true;
        this.router.navigate(['/downloadValidDocument']);
        this.notiService.success('Success!', 'Profile Updated SuccessFully', {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
      } else {
        this.isSubmitButtonVisible = false;
        this.notiService.error('Error!', resp.msg, {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
      }
    });
  }

  open(content) {
    window.scrollTo(30, 0);
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }


}
