import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserAuthRoutingModule } from './user-auth-routing.module';
import { PaymentTimerpageComponent } from './payment-timerpage/payment-timerpage.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { UserService } from '../../_services/user.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UpdateProfileComponent } from './update-profile/update-profile.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from '../../_guards/auth.guard';
import { AccountDetailComponent } from './account-detail/account-detail.component';
import { BuyerInvoiceComponent } from './buyer-invoice/buyer-invoice.component';
import { NgBusyModule } from 'ng-busy';
import { SuccessComponent } from './success/success.component';
import { FailComponent } from './fail/fail.component';
import { CancelComponent } from './cancel/cancel.component';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NonIndividualBuyerProfileComponent } from './non-individual-buyer-profile/non-individual-buyer-profile.component';
import { IndividualBuyerProfileComponent } from './individual-buyer-profile/individual-buyer-profile.component';
import { ChangeContactComponent } from './change-contact/change-contact.component';
import { ChangeContactOtpComponent } from './change-contact-otp/change-contact-otp.component';
import { UploadValidDocumentComponent } from './upload-valid-document/upload-valid-document.component';
import { DownloadValidDocumentComponent } from './download-valid-document/download-valid-document.component';
import { TransactionViewComponent } from './transaction-view/transaction-view.component';
import { SplitLastPipe } from 'src/_helpers/split.last.pipe';
import { FinishComponent } from './finish/finish.component';

@NgModule({
  declarations: [
    PaymentTimerpageComponent,
    ChangePasswordComponent,
    HeaderComponent,
    FooterComponent,
    UpdateProfileComponent,
    HomeComponent,
    AccountDetailComponent,
    BuyerInvoiceComponent,
    SuccessComponent,
    FailComponent,
    CancelComponent,
    NonIndividualBuyerProfileComponent,
    IndividualBuyerProfileComponent,
    ChangeContactComponent,
    ChangeContactOtpComponent,
    UploadValidDocumentComponent,
    DownloadValidDocumentComponent,
    TransactionViewComponent,
    SplitLastPipe,
    FinishComponent
  ],
  imports: [
    CommonModule,
    UserAuthRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    NgBusyModule,
    DatepickerModule,
    BsDatepickerModule
  ],
  exports: [
    PaymentTimerpageComponent,
    ChangePasswordComponent,
    HeaderComponent,
    FooterComponent,
    UpdateProfileComponent,
    HomeComponent,
    AccountDetailComponent,
    BuyerInvoiceComponent,
    SuccessComponent,
    FailComponent,
    CancelComponent,
    NonIndividualBuyerProfileComponent,
    IndividualBuyerProfileComponent,
    ChangeContactComponent,
    ChangeContactOtpComponent,
    UploadValidDocumentComponent,
    DownloadValidDocumentComponent,
    TransactionViewComponent,
    SplitLastPipe,
    FinishComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [UserService, AuthGuard]
})
export class UserAuthModule { }
