import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { UserService } from '../../../_services/user.service';
import { NotificationsService } from 'angular2-notifications';

@Component({
  selector: 'app-cancel',
  templateUrl: './cancel.component.html',
  styleUrls: ['./cancel.component.css']
})
export class CancelComponent implements OnInit {

  paramData: string;
   confirmPayload = {
  'orderRef': '',
   'status': ''
  };
;
  constructor(private activatedRoute: ActivatedRoute, 
    private userService: UserService,
    private notiService: NotificationsService,
    private router: Router) {
    // subscribe to router event
    this.activatedRoute.queryParams.subscribe((params: Params) => {
      this.paramData = params.Ref;
    });
  }

  ngOnInit() {
    window.scrollTo(500, 0);
    this.confirmPayload.orderRef = this.paramData;
    this.confirmPayload.status = 'success';
    this.userService.getResvePaymentConfirm(this.confirmPayload).subscribe(respData => {
      if(respData.status === true) {
        this.notiService.success('Success!', respData.msg, {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
        this.router.navigate(['/home']);
      } else {
        this.notiService.error('Error!', respData.msg, {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
      }
    });
  }

}
