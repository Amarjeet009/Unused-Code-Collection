import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeContactOtpComponent } from './change-contact-otp.component';

describe('ChangeContactOtpComponent', () => {
  let component: ChangeContactOtpComponent;
  let fixture: ComponentFixture<ChangeContactOtpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangeContactOtpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeContactOtpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
