import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-contact-otp',
  templateUrl: './change-contact-otp.component.html',
  styleUrls: ['./change-contact-otp.component.css']
})
export class ChangeContactOtpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scrollTo(500, 0);
  }

}
