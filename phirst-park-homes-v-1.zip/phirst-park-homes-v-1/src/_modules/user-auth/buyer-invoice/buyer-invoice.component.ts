import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-buyer-invoice',
  templateUrl: './buyer-invoice.component.html',
  styleUrls: ['./buyer-invoice.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class BuyerInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scrollTo(500, 0);
  }

}
