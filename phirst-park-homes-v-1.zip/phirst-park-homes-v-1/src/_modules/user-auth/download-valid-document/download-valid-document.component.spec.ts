import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DownloadValidDocumentComponent } from './download-valid-document.component';

describe('DownloadValidDocumentComponent', () => {
  let component: DownloadValidDocumentComponent;
  let fixture: ComponentFixture<DownloadValidDocumentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DownloadValidDocumentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DownloadValidDocumentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
