import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/_services/user.service';
import { NotificationsService } from 'angular2-notifications';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
@Component({
  selector: 'app-download-valid-document',
  templateUrl: './download-valid-document.component.html',
  styleUrls: ['./download-valid-document.component.css']
})
export class DownloadValidDocumentComponent implements OnInit {
  public baseUrl = 'http://dr2myglbq65g4.cloudfront.net/BuyerDocuments/';

  public phirstRequirementsChecklist = this.baseUrl + 'phirstRequirementsChecklist.pdf';
  public conditionalPurchaseAgreement = this.baseUrl + 'conditionalPurchaseAgreement.pdf';
  public dataPrivacyConsent = this.baseUrl + 'dataPrivacyConsent.pdf';
  public houseSpecification = this.baseUrl + 'houseSpecification.pdf';

  public phirstBuyersGuide = this.baseUrl + 'phirstBuyersGuide.pdf';
  public BIRFormNo1904 = this.baseUrl + 'BIRFormNo1904.pdf';
  public deedofAbsoluteSale = this.baseUrl + 'deedofAbsoluteSale.pdf';
  public _5ConvenientBuyersSteps = this.baseUrl + '5ConvenientBuyersSteps.pdf';
  public buyerInformationSheet = this.baseUrl + 'buyerInformationSheet.pdf';
  public buyerInformationSheet2 = 'http://dr2myglbq65g4.cloudfront.net/Buyers/' + localStorage.getItem('myid') + '/uploads/BIS/BIS.pdf';
  public unifiedHomeLoanApplication = this.baseUrl + 'unifiedHomeLoanApplication.pdf';
  downloadModel = {
    category: '',
    file: ''
  };
  busy: Subscription;
  userModel = {
    'userId': localStorage.getItem('emailId')
  };
  public reserved_sale_documents: any = 0;
  public contracted_sale_documents: any = 0;
  public if_locally_employed: any = 0;
  public if_employed_abroad: any = 0;
  public if_self_employed: any = 0;
  public additional_requirements_banks: any = 0;
  public source_of_income_from_rental: any = 0;
  constructor(
    private userService: UserService, 
    private notiService: NotificationsService,
    private router: Router) { }

  ngOnInit() {
    window.scrollTo(500, 0);
    this.userService.getBuyerBasicDetails(this.userModel).subscribe(responseData => {
      if (responseData.status === true) {
        this.reserved_sale_documents = responseData.data.reserved_sale_documents;
        this.contracted_sale_documents = responseData.data.contracted_sale_documents;
        this.if_locally_employed = responseData.data.if_locally_employed;
        this.if_employed_abroad = responseData.data.if_employed_abroad;
        this.if_self_employed = responseData.data.if_self_employed;
        this.additional_requirements_banks = responseData.data.additional_requirements_banks;
        this.source_of_income_from_rental = responseData.data.source_of_income_from_rental;
      }
    }, error => {
      console.error('Buyer Basic Details ==>', error);
    });
  }

  clickToFinishIcon() {
    if (this.reserved_sale_documents === 1 &&
      this.contracted_sale_documents === 1 &&
      this.if_locally_employed === 1 &&
      this.if_employed_abroad === 1 &&
      this.if_self_employed === 1 &&
      this.additional_requirements_banks === 1 &&
      this.source_of_income_from_rental === 1) {
        this.router.navigate(['/allDocumentSubmittedSuccessfully']);
    } else {
      this.notiService.error('Error!', 'Submit All Required Documents', {
        timeOut: 3000,
        showProgressBar: true,
        pauseOnHover: true,
        clickToClose: true
      }); 
    }
  }
  clickDownloadBISForm() {
    this.busy = this.userService.downloadBISForm().subscribe(respData => {
      if (respData.status === true) {
        var url = respData.URL;
        var win = window.open(url, '_blank');
        win.opener = null;
        win.focus();
      } else {
        this.notiService.error('Error!', respData.msg, {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
      }
    }, (err) => {
      console.error(err);
    });
  }

  downloadUloadedbuyersDocuments(category: any, filename: any) {
    this.downloadModel.category = category;
    this.downloadModel.file = filename;
    this.busy = this.userService.downloadUloadedbuyersDocuments(this.downloadModel).subscribe(resData => {
      if (resData.status === true) {
        var url = resData.URL;
        var win = window.open(url, '_blank');
        win.opener = null;
        win.focus();
      } else {
        this.notiService.error('Error!', resData.msg, {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
      }
    }, err => { console.error(err); });
  }
}
