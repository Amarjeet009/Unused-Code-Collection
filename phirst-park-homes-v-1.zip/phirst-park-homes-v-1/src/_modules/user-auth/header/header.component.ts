import { Component, OnInit, Input } from '@angular/core';
import { UserService } from '../../../_services/user.service';
import { Router } from '@angular/router';
import { NotificationsService } from 'angular2-notifications';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
status: any;
userModel = {
  'userId': localStorage.getItem('emailId')
};
is_individual_buyer: any;
  constructor(private userService: UserService,
    private router: Router,
    private notiService: NotificationsService) { }

  ngOnInit() {
   this.userService.getBuyerProperty().subscribe(respData => {
        if (respData.status === true) {
       this.status = respData.data[0].status;
       this.userService.setForBuyerPropertiesPaymentOption('payment_status', respData.data[0].status);
    }
   });

   this.userService.getBuyerBasicDetails(this.userModel).subscribe(responseData => {
    if (responseData.status === true  ) {
      this.is_individual_buyer = responseData.data.is_individual_buyer;
    }
  }, error => {
    console.error('Buyer Basic Details ==>', error);
  });
  }

  userLogout() {
    this.userService.userLogout().subscribe(respData => {
      if (respData.status === true) {
        this.router.navigate(['/login']);
        this.notiService.success('Success!', respData.msg, {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
        localStorage.clear();
        location.reload();

      } else if (respData.logout == true) {
        this.router.navigate(['/login']);
        this.notiService.success('Success!', 'Logout Successfully', {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
        localStorage.clear();
        location.reload();
      } else {
        this.notiService.error('Error!', respData.msg, {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
      }
    });
  }
}
