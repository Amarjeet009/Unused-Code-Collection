import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../_services/user.service';

@Component({
  selector: 'app-non-individual-buyer-profile',
  templateUrl: './non-individual-buyer-profile.component.html',
  styleUrls: ['./non-individual-buyer-profile.component.css']
})
export class NonIndividualBuyerProfileComponent implements OnInit {

  detailsModel = {
    'userId': localStorage.getItem('emailId')
  };

  nIBNameOfBusiness = '-----';
  nIBNatureOfBusiness = '-----';
  nIBYearsInOperation = '-----';
  nIBBusinessType = '-----';
  nIBContactNo = '-----';
  nIBEmailAddress = '-----';
  nIBTaxIdentificationNo = '-----';
  nIBSecRegistrationNo = '-----';
  nIBSssNo = '-----';
  nIBPrincipalOfficeAddress = '-----';
  nIBPrincipalOfficeAddressZipCode = '-----';
  nIBOtherAddress = '-----';
  nIBOtherAddressZipCode = '-----';

  aSIFirstName = '-----';
  aSIMiddleName = '-----';
  aSILastName = '-----';
  aSISuffixName = '-----';
  aSIGender = '-----';
  aSICivilStatus = '-----';
  aSIBirthDate: any;
  aSICitizenship = '-----';
  aSIDesignation = '-----';
  aSItaxIdentificationNo = '-----';
  aSITypeOfValidId = '-----';
  aSIIdNo = '-----';
  aSIMobile = '-----';
  aSIOfficePhoneNo = '-----';
  aSIfaxNo = '-----';
  aSIEmailAddress = '-----';
  aSIAddress = '-----';
  aSIZipCode = '-----';

  cPIFirstName = '-----';
  cPIMiddleName = '-----';
  cPILastName = '-----';
  cPISuffixName = '-----';
  cPIGender = '-----';
  cPICivilStatus = '-----';
  cPIBirthDate: any;
  cPICitizenship = '-----';
  cPIDesignation = '-----';
  cPItaxIdentificationNo = '-----';
  cPITypeOfValidId = '-----';
  cPIIdNo = '-----';
  cPIMobile = '-----';
  cPIOfficePhoneNo = '-----';
  cPIfaxNo = '-----';
  cPIEmailAddress = '-----';
  cPIAddress = '-----';
  cPIZipCode = '-----';
  constructor(private userService: UserService) { }

  ngOnInit() {
    window.scrollTo(500, 0);
    this.userService.getBuyerDetails(this.detailsModel).subscribe(responseData => {
      this.nIBNameOfBusiness = responseData.nonIndividualBuyer.nIBuyerBusinessInformation.nIBNameOfBusiness;
      this.nIBNatureOfBusiness = responseData.nonIndividualBuyer.nIBuyerBusinessInformation.nIBNatureOfBusiness;
      this.nIBYearsInOperation = responseData.nonIndividualBuyer.nIBuyerBusinessInformation.nIBYearsInOperation;
      this.nIBBusinessType = responseData.nonIndividualBuyer.nIBuyerBusinessInformation.nIBBusinessType;
      this.nIBContactNo = responseData.nonIndividualBuyer.nIBuyerBusinessInformation.nIBContactNo;
      this.nIBEmailAddress = responseData.nonIndividualBuyer.nIBuyerBusinessInformation.nIBEmailAddress;
      this.nIBTaxIdentificationNo = responseData.nonIndividualBuyer.nIBuyerBusinessInformation.nIBTaxIdentificationNo;
      this.nIBSecRegistrationNo = responseData.nonIndividualBuyer.nIBuyerBusinessInformation.nIBSecRegistrationNo;
      this.nIBSssNo = responseData.nonIndividualBuyer.nIBuyerBusinessInformation.nIBSssNos;
      this.nIBPrincipalOfficeAddress = responseData.nonIndividualBuyer.nIBuyerBusinessInformation.nIBPrincipalOfficeAddress;
      this.nIBPrincipalOfficeAddressZipCode = responseData.nonIndividualBuyer.nIBuyerBusinessInformation.nIBPrincipalOfficeAddressZipCode;
      this.nIBOtherAddress = responseData.nonIndividualBuyer.nIBuyerBusinessInformation.nIBOtherAddress;
      this.nIBOtherAddressZipCode = responseData.nonIndividualBuyer.nIBuyerBusinessInformation.nIBYearsInOperation;


      this.cPIFirstName = responseData.nonIndividualBuyer.contactPersonInformation.cPIFirstName;
      this.cPIMiddleName = responseData.nonIndividualBuyer.contactPersonInformation.cPIMiddleName;
      this.cPILastName = responseData.nonIndividualBuyer.contactPersonInformation.cPILastName;
      this.cPISuffixName = responseData.nonIndividualBuyer.contactPersonInformation.cPISuffixName;
      this.cPIGender = responseData.nonIndividualBuyer.contactPersonInformation.cPIGender;
      this.cPICivilStatus = responseData.nonIndividualBuyer.contactPersonInformation.cPICivilStatus;
      if (responseData.nonIndividualBuyer.contactPersonInformation.cPIBirthDate === 'N/A' || responseData.nonIndividualBuyer.contactPersonInformation.cPIBirthDate === 'NaN/NaN/NaN') {
        this.cPIBirthDate = null;
      } else {
        this.cPIBirthDate = responseData.nonIndividualBuyer.contactPersonInformation.cPIBirthDate;
      }
      this.cPICitizenship = responseData.nonIndividualBuyer.contactPersonInformation.cPICitizenship;
      this.cPIDesignation = responseData.nonIndividualBuyer.contactPersonInformation.cPIDesignation;
      this.cPItaxIdentificationNo = responseData.nonIndividualBuyer.contactPersonInformation.cPItaxIdentificationNo;
      this.cPITypeOfValidId = responseData.nonIndividualBuyer.contactPersonInformation.cPITypeOfValidId;
      this.cPIIdNo = responseData.nonIndividualBuyer.contactPersonInformation.cPIIdNo;
      this.cPIMobile = responseData.nonIndividualBuyer.contactPersonInformation.cPIMobile;
      this.cPIOfficePhoneNo = responseData.nonIndividualBuyer.contactPersonInformation.cPIOfficePhoneNo;
      this.cPIfaxNo = responseData.nonIndividualBuyer.contactPersonInformation.cPIfaxNo;
      this.cPIEmailAddress = responseData.nonIndividualBuyer.contactPersonInformation.cPIEmailAddress;
      this.cPIAddress = responseData.nonIndividualBuyer.contactPersonInformation.cPIAddress;
      this.cPIZipCode = responseData.nonIndividualBuyer.contactPersonInformation.cPIZipCode;

      this.aSIFirstName = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSIFirstName;
      this.aSIMiddleName = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSIMiddleName;
      this.aSILastName = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSILastName;
      this.aSISuffixName = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSISuffixName;
      this.aSIGender = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSIGender;
      this.aSICivilStatus = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSICivilStatus;
      if (responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSIBirthDate === 'N/A' || responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSIBirthDate ===  'NaN/NaN/NaN') {
        this.aSIBirthDate = null;
      } else {
        this.aSIBirthDate = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSIBirthDate;
      }
      this.aSICitizenship = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSICitizenship;
      this.aSIDesignation = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSIDesignation;
      this.aSItaxIdentificationNo = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSItaxIdentificationNo;
      this.aSITypeOfValidId = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSITypeOfValidId;
      this.aSIIdNo = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSIIdNo;
      this.aSIMobile = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSIMobile;
      this.aSIOfficePhoneNo = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSIOfficePhoneNo;
      this.aSIfaxNo = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSIfaxNo;
      this.aSIEmailAddress = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSIEmailAddress;
      this.aSIAddress = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSIAddress;
      this.aSIZipCode = responseData.nonIndividualBuyer.authorisedSignatoryInformation.aSIZipCode;
    });
  }

}
