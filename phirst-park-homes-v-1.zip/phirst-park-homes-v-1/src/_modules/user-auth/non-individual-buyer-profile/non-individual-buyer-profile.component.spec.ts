import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NonIndividualBuyerProfileComponent } from './non-individual-buyer-profile.component';

describe('NonIndividualBuyerProfileComponent', () => {
  let component: NonIndividualBuyerProfileComponent;
  let fixture: ComponentFixture<NonIndividualBuyerProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NonIndividualBuyerProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NonIndividualBuyerProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
