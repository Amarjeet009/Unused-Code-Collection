import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NotificationsService } from 'angular2-notifications';
import { UserService } from '../../../_services/user.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {
  passwordResetForm: FormGroup;
  submitted = false;
  public busy: Subscription;

  constructor(
    private formBuilder: FormBuilder,
    private notiService: NotificationsService,
    private userService: UserService,
    private router: Router
    ) { }

  ngOnInit() {
    window.scrollTo(500, 0);
    this.passwordResetForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
    });
  }

  get f() { return this.passwordResetForm.controls; }

  userPasswordReset() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.passwordResetForm.invalid) {
      return;
    }
  this.busy =  this.userService.getUserPasswordReset(this.passwordResetForm.value).subscribe(respData => {
      if (respData.status === true) {
        this.router.navigate(['/login']);
        this.notiService.success('Success!', respData.msg, {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
      } else {
        this.notiService.error('Error!', respData.msg, {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
      }
    });
  }

}
