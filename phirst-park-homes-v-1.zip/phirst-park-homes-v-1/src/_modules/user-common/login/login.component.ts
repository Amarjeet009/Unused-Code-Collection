import { Component, OnInit, ChangeDetectorRef, ViewEncapsulation } from '@angular/core';
import { AuthenticationService } from '../../../_services/authentication.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationsService } from 'angular2-notifications';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class LoginComponent implements OnInit {
  public loginForm: FormGroup;
  public submitted = false;
  returnUrl: string;
  public inputType = 'password';
  public visible = false;
  public showStyle = {
    marginLeft: '0%',
    fontSize: '14px',
    color: 'blue',
    textDecoration: 'underline'
  };
  public busy: Subscription;
 public hideStyle = {
    marginLeft: '0%',
    fontSize: '14px',
    color: 'red',
    textDecoration: 'underline'
  };
  constructor(private authenticationService: AuthenticationService,
    private formBuilder: FormBuilder,
    private changeDetectorRef: ChangeDetectorRef,
    private notiService: NotificationsService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    window.scrollTo(500, 0);
    this.loginForm = this.formBuilder.group({
      userId: ['', [Validators.required, Validators.minLength(10)]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  get f() { return this.loginForm.controls; }

  show() {
    this.inputType = 'text';
    this.visible = true;
    this.changeDetectorRef.markForCheck();
  }

  hide() {
    this.inputType = 'password';
    this.visible = false;
    this.changeDetectorRef.markForCheck();
  }

  userLogin() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }
  this.busy =  this.authenticationService.userLogin(this.loginForm.value).subscribe(respData => {
      if (respData.status === true) {
        localStorage.setItem('emailId', this.loginForm.value['userId']);
        this.router.navigate(['/home']);
        this.notiService.success('Success!', respData.msg, {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
      } else {
        this.notiService.error('Error!', respData.msg, {
          timeOut: 3000,
          showProgressBar: true,
          pauseOnHover: true,
          clickToClose: true
        });
      }
    });
  }

}
