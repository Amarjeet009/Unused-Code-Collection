import { NgModule } from '@angular/core';
import { CommonModule} from '@angular/common';

import { UserCommonRoutingModule } from './user-common-routing.module';
import { LoginComponent } from './login/login.component';
import { AuthenticationService } from '../../_services/authentication.service';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SimpleNotificationsModule } from 'angular2-notifications';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { UserService } from '../../_services/user.service';
import { NgBusyModule } from 'ng-busy';


@NgModule({
  declarations: [
    LoginComponent,
    ResetPasswordComponent,
  ],
  imports: [
    CommonModule,
    UserCommonRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    SimpleNotificationsModule,
    FormsModule,
    NgBusyModule
  ],
  exports: [
    LoginComponent,
    ResetPasswordComponent,
  ],
  providers: [
    AuthenticationService,
    UserService
  ]
})
export class UserCommonModule { }
