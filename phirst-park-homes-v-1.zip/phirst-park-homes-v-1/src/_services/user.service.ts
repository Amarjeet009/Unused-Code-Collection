import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { Config } from 'src/_config/config';
import { ChangePasswordModel } from 'src/_models/user.model';
import { catchError, map } from 'rxjs/operators';
import { UpdateUserModel } from '../_models/update.user.model';
import { throwError } from 'rxjs';
import { InitiatePropertyBuyModel } from '../_models/initiate-property-buy-model';
import { GetBuyerPropertyModel } from '../_models/get-buyer-property.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  userToken: string;
  public headers: HttpHeaders = new HttpHeaders();
  public headersFormData: HttpHeaders = new HttpHeaders();
  /**
   * @author amarjeet rao;
   * @param http ;
   */

  private payment_status = {};
  private user_Basic_Details = {};
  private startDateSubject: BehaviorSubject<any>;
  public startDate: Observable<any>;

  public getBuyerPropertyModel: GetBuyerPropertyModel = new GetBuyerPropertyModel();

  constructor(private http: HttpClient) {
    this.headers = this.headers
      .append('Accept', 'application/json')
      .append('Content-Type', 'application/json')
      .append('Authorization', 'Bearer ' + localStorage.getItem('token'));

    this.headersFormData = this.headersFormData
      .append('Authorization', 'Bearer ' + localStorage.getItem('token'));

    localStorage.setItem('timeZone', 'Asia/Kolkata')
    this.startDateSubject = new BehaviorSubject<any>(localStorage.getItem('timeZone'));
    this.startDate = this.startDateSubject.asObservable();

  }

  public get currentDateValue(): any {
    return this.startDateSubject.value;
  }

  /**
   * 
   * @param option 
   * @param value 
   */
  setForBuyerPropertiesPaymentOption(option: any, value: any) {
    this.payment_status[option] = value;
  }

  getForBuyerPropertiesPaymentOption() {
    return this.payment_status;
  }

  setForUserBasicDetailsOption(details: any, value: any) {
    this.user_Basic_Details[details] = value;
  }

  getForUserBasicDetailsOption() {
    return this.user_Basic_Details;
  }

  /**
   * @method UserLogout
   * @author amarjeet rao
   */
  userLogout(): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/logout', {}, { headers: this.headers })
      .pipe(catchError(this.errorHandler));
  }

  /**
   * @method FirstTimeChangePasswordByUserAfterLogin
   * @author amarjeet rao;
   * @param objModel ;
   */
  changeUserPassword(objModel: ChangePasswordModel): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/change-password', objModel, { headers: this.headers })
      .pipe(catchError(this.errorHandler));
  }
  /**
   * @method fetchBuyerDetails
   * @author amarjeet rao;
   * @param obj ;
   */
  getBuyerDetails(obj: any): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/get-details', obj, { headers: this.headers })
      .pipe(catchError(this.errorHandler));
  }
  /**
   * @method UpdateBuyerDetails
   * @author amarjeet rao;
   * @param objModel ;
   */
  getUpdateBuyerDetails(objModel: UpdateUserModel): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/upload-details', objModel, { headers: this.headers })
      .pipe(catchError(this.errorHandler));
  }
  /**
     * @method BuyerBasicDetails
     * @author amarjeet rao;
     * @param objModel ;
     */
  getBuyerBasicDetails(objModel: any): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/get-basic-details', objModel, { headers: this.headers })
      .pipe(map(responseData => {
        if (responseData.status === true) {
          localStorage.setItem('timeZone', responseData.data.country_code);
          this.startDateSubject.next(responseData.data.country_code);
        }
        return responseData;
      }), catchError(this.errorHandler));
  }
  /**
     * @method UserPasswordResetWithoutLogin
     * @author amarjeet rao;
     * @param objModel ;
     */
  getUserPasswordReset(objModel: any): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/reset-password', objModel, { headers: this.headers })
      .pipe(catchError(this.errorHandler));
  }

  getBuyerProperty(): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/get-buyer-property', {}, { headers: this.headers })
      .pipe(catchError(this.errorHandler));
  }

  getBuyerPropertiesDetails(model: any): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/get-buyer-properties', model, { headers: this.headers })
      .pipe(catchError(this.errorHandler));
  }


  getPropertyListSellerData(objModel: any): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/get-property-list', objModel, { headers: this.headers })
      .pipe(catchError(this.errorHandler));
  }

  getInitiatePropertyBuy(objModel: InitiatePropertyBuyModel): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/initiate-property-buy', objModel, { headers: this.headers })
      .pipe(catchError(this.errorHandler));
  }

  getUpdatePaymentStatus(objModel: any): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/update-payment-status', objModel, { headers: this.headers })
      .pipe(catchError(this.errorHandler));
  }
  buyerMakeReservePayment(objModel: any): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/resv-payment', objModel, { headers: this.headers })
      .pipe(catchError(this.errorHandler));
  }

  getResvePaymentConfirm(objModel: any): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/resv-payment-confirm', objModel, { headers: this.headers })
      .pipe(catchError(this.errorHandler));
  }

  uploadProfilePic(objModel: any) {
    return this.http.post<any>(Config.api_url + '/buyer/upload-profile-pic', objModel, { headers: this.headersFormData })
      .pipe(catchError(this.errorHandler));
  }
  downloadBISForm(): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/downlaod-BIS', {}, { headers: this.headers })
      .pipe(catchError(this.errorHandler));
  }

  uploadAllReservedSaleDocuments(model: any): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/upload-buyer-docs', model, { headers: this.headersFormData })
      .pipe(catchError(this.errorHandler));
  }

  downloadUloadedbuyersDocuments(fileObject: any): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/download-buyer-docs', fileObject, { headers: this.headers })
      .pipe(catchError(this.errorHandler));
  }
  errorHandler(respError: HttpErrorResponse | any) {
    if (respError.error instanceof ErrorEvent) {
      console.error('Client Side Error: ' + respError);
    } else {
      console.error('Server Side Error: ' + respError);
    }
    return throwError(respError || 'Server Downgrade Error');
  }


}
