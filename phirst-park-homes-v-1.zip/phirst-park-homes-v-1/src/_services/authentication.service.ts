import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { UserLogin } from '../_models/user.model';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { Config } from 'src/_config/config';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  private headers: HttpHeaders = new HttpHeaders();

  private currentUserSubject: BehaviorSubject<any>;
  public currentUser: Observable<any>;

  constructor(private http: HttpClient) {
    this.headers = this.headers.append('Accept', 'application/json')
      .append('Content-Type', 'application/json');

    this.currentUserSubject = new BehaviorSubject<any>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): any {
    return this.currentUserSubject.value;
  }

  /**
   * @param user;
   */
  userLogin(user: UserLogin): Observable<any> {
    return this.http.post<any>(Config.api_url + '/buyer/login', user, { headers: this.headers })
      .pipe(catchError(this.errorHandler),
        map(userData => {
          if (userData && userData.bearer) {
            localStorage.setItem('token', userData.bearer);
            localStorage.setItem('currentUser', JSON.stringify(userData));

            this.currentUserSubject.next(userData);
          }
          return userData;
        }));
  }

  errorHandler(respError: HttpErrorResponse) {
    if (respError.error instanceof ErrorEvent) {
      console.error('Client Side Error: ' + respError);
    } else {
      console.error('Server Side Error: ' + respError);
    }
    return throwError(respError || 'Server Downgrade Error');
  }
}
