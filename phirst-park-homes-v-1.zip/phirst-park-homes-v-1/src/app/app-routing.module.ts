import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from '../_modules/user-common/login/login.component';
import { ResetPasswordComponent } from '../_modules/user-common/reset-password/reset-password.component';
import { ChangePasswordComponent } from '../_modules/user-auth/change-password/change-password.component';
import { AuthGuard } from '../_guards/auth.guard';
import { PaymentTimerpageComponent } from '../_modules/user-auth/payment-timerpage/payment-timerpage.component';
import { UpdateProfileComponent } from '../_modules/user-auth/update-profile/update-profile.component';
import { HomeComponent } from '../_modules/user-auth/home/home.component';
import { AccountDetailComponent } from '../_modules/user-auth/account-detail/account-detail.component';
import { BuyerInvoiceComponent } from '../_modules/user-auth/buyer-invoice/buyer-invoice.component';
import { SuccessComponent } from '../_modules/user-auth/success/success.component';
import { FailComponent } from '../_modules/user-auth/fail/fail.component';
import { CancelComponent } from '../_modules/user-auth/cancel/cancel.component';
import { IndividualBuyerProfileComponent } from '../_modules/user-auth/individual-buyer-profile/individual-buyer-profile.component';
import { ChangeContactComponent } from '../_modules/user-auth/change-contact/change-contact.component';
import { ChangeContactOtpComponent } from '../_modules/user-auth/change-contact-otp/change-contact-otp.component';
import { UploadValidDocumentComponent } from '../_modules/user-auth/upload-valid-document/upload-valid-document.component';
import { DownloadValidDocumentComponent } from '../_modules/user-auth/download-valid-document/download-valid-document.component';
import { NonIndividualBuyerProfileComponent } from '../_modules/user-auth/non-individual-buyer-profile/non-individual-buyer-profile.component';
import {TransactionViewComponent} from '../_modules/user-auth/transaction-view/transaction-view.component';
import { FinishComponent } from '../_modules/user-auth/finish/finish.component';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: 'resetPasssword',
    component: ResetPasswordComponent
  },
  {
    path: 'change-password',
    component: ChangePasswordComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'make-payment/:id',
    component: PaymentTimerpageComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'update-profile',
    component: UpdateProfileComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'home',
    component: HomeComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'propertyInformation/:id',
    component: AccountDetailComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'buyerInvoice',
    component: BuyerInvoiceComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'success',
    component: SuccessComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'fail',
    component: FailComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'cancel',
    component: CancelComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'nonIndividualBuyerProfile',
    component: NonIndividualBuyerProfileComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'individualBuyerProfile',
    component: IndividualBuyerProfileComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'changeContact',
    component: ChangeContactComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'verifyOTP',
    component: ChangeContactOtpComponent,
    canActivate: [AuthGuard]
  },

  {
    path: 'uploadValidDocument',
    component: UploadValidDocumentComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'downloadValidDocument',
    component: DownloadValidDocumentComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'transaction-view',
    component: TransactionViewComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'allDocumentSubmittedSuccessfully',
    component: FinishComponent,
    canActivate: [AuthGuard]
  },
  { path: '**', redirectTo: '/home', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
