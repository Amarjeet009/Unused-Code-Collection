csv-manager
============

An abstract model to manage CSV files in java.